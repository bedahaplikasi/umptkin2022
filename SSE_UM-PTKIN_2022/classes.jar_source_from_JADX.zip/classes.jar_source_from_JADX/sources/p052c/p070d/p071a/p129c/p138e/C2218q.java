package p052c.p070d.p071a.p129c.p138e;

/* renamed from: c.d.a.c.e.q */
final class C2218q implements Runnable {

    /* renamed from: c */
    private final C2217p f7905c;

    C2218q(C2217p pVar) {
        this.f7905c = pVar;
    }

    public final void run() {
        synchronized (this.f7905c.f7903b) {
            if (this.f7905c.f7904c != null) {
                this.f7905c.f7904c.mo6737c();
            }
        }
    }
}
