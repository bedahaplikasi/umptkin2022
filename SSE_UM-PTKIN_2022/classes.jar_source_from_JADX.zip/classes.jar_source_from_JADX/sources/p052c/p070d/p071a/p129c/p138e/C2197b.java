package p052c.p070d.p071a.p129c.p138e;

/* renamed from: c.d.a.c.e.b */
public interface C2197b {
    /* renamed from: c */
    void mo6737c();
}
