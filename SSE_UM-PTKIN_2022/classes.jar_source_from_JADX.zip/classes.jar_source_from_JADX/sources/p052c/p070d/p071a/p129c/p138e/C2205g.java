package p052c.p070d.p071a.p129c.p138e;

/* renamed from: c.d.a.c.e.g */
public interface C2205g<TResult, TContinuationResult> {
    /* renamed from: a */
    C2206h<TContinuationResult> mo6642a(TResult tresult);
}
