package p052c.p070d.p071a.p129c.p130a;

/* renamed from: c.d.a.c.a.n */
public final /* synthetic */ class C2143n implements Runnable {

    /* renamed from: c */
    public final C2147r f7769c;

    public /* synthetic */ C2143n(C2147r rVar) {
        this.f7769c = rVar;
    }

    public final void run() {
        this.f7769c.mo6670d();
    }
}
