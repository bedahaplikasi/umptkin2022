package p052c.p070d.p071a.p129c.p134c.p136b;

/* renamed from: c.d.a.c.c.b.o */
public final class C2182o {

    /* renamed from: a */
    private int f7833a;

    /* renamed from: b */
    private final C2185r f7834b = C2185r.DEFAULT;

    /* renamed from: a */
    public final C2182o mo6709a(int i) {
        this.f7833a = i;
        return this;
    }

    /* renamed from: b */
    public final C2186s mo6710b() {
        return new C2181n(this.f7833a, this.f7834b);
    }
}
