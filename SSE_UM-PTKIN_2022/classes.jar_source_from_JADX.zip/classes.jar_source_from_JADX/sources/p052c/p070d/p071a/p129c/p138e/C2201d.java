package p052c.p070d.p071a.p129c.p138e;

/* renamed from: c.d.a.c.e.d */
public interface C2201d {
    /* renamed from: d */
    void mo6759d(Exception exc);
}
