package p052c.p070d.p071a.p129c.p138e;

/* renamed from: c.d.a.c.e.e */
public interface C2203e<TResult> {
    /* renamed from: b */
    void mo6761b(TResult tresult);
}
