package p052c.p070d.p071a.p129c.p134c.p136b;

/* renamed from: c.d.a.c.c.b.r */
public enum C2185r {
    DEFAULT,
    SIGNED,
    FIXED;
    

    /* renamed from: f */
    private static final C2185r[] f7839f = null;

    static {
        C2185r rVar = new C2185r("DEFAULT", 0);
        DEFAULT = rVar;
        C2185r rVar2 = new C2185r("SIGNED", 1);
        SIGNED = rVar2;
        C2185r rVar3 = new C2185r("FIXED", 2);
        FIXED = rVar3;
        f7839f = new C2185r[]{rVar, rVar2, rVar3};
    }
}
