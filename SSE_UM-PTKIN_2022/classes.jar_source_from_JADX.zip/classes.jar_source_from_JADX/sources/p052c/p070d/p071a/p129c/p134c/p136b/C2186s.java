package p052c.p070d.p071a.p129c.p134c.p136b;

/* renamed from: c.d.a.c.c.b.s */
public @interface C2186s {
    int zza();

    C2185r zzb() default C2185r.DEFAULT;
}
