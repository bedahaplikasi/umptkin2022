package p052c.p070d.p071a.p129c.p130a;

import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: c.d.a.c.a.g */
final class C2136g implements Parcelable.Creator<C2138i> {
    C2136g() {
    }

    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        return new C2138i(parcel.readStrongBinder());
    }

    public final /* bridge */ /* synthetic */ Object[] newArray(int i) {
        return new C2138i[i];
    }
}
