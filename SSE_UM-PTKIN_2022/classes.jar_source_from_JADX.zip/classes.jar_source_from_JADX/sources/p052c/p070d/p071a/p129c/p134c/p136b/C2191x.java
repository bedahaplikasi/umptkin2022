package p052c.p070d.p071a.p129c.p134c.p136b;

import com.google.firebase.p173m.C3008d;
import com.google.firebase.p173m.C3010f;
import java.io.OutputStream;
import java.util.Map;

/* renamed from: c.d.a.c.c.b.x */
public final class C2191x {

    /* renamed from: a */
    private final Map<Class<?>, C3008d<?>> f7856a;

    /* renamed from: b */
    private final Map<Class<?>, C3010f<?>> f7857b;

    /* renamed from: c */
    private final C3008d<Object> f7858c;

    C2191x(Map<Class<?>, C3008d<?>> map, Map<Class<?>, C3010f<?>> map2, C3008d<Object> dVar) {
        this.f7856a = map;
        this.f7857b = map2;
        this.f7858c = dVar;
    }

    /* renamed from: a */
    public final void mo6727a(Object obj, OutputStream outputStream) {
        new C2188u(outputStream, this.f7856a, this.f7857b, this.f7858c).mo6724i(obj);
    }
}
