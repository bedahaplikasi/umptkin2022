package p052c.p070d.p071a.p129c.p130a;

import java.util.concurrent.ScheduledFuture;
import p052c.p070d.p071a.p129c.p138e.C2199c;
import p052c.p070d.p071a.p129c.p138e.C2206h;

/* renamed from: c.d.a.c.a.b0 */
public final /* synthetic */ class C2127b0 implements C2199c {

    /* renamed from: a */
    public final C2131d f7740a;

    /* renamed from: b */
    public final String f7741b;

    /* renamed from: c */
    public final ScheduledFuture f7742c;

    public /* synthetic */ C2127b0(C2131d dVar, String str, ScheduledFuture scheduledFuture) {
        this.f7740a = dVar;
        this.f7741b = str;
        this.f7742c = scheduledFuture;
    }

    /* renamed from: a */
    public final void mo6639a(C2206h hVar) {
        this.f7740a.mo6645e(this.f7741b, this.f7742c, hVar);
    }
}
