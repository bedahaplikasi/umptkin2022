package p052c.p070d.p071a.p129c.p131b.p132b;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import p052c.p070d.p071a.p129c.p131b.p132b.C2157a;

/* renamed from: c.d.a.c.b.b.b */
final class C2159b implements C2157a.C2158a {
    C2159b() {
    }

    /* renamed from: a */
    public final ScheduledExecutorService mo6686a() {
        return Executors.newSingleThreadScheduledExecutor();
    }
}
