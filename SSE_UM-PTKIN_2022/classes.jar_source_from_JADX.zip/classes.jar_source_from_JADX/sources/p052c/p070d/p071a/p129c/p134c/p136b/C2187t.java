package p052c.p070d.p071a.p129c.p134c.p136b;

import com.google.firebase.p173m.C3008d;
import com.google.firebase.p173m.C3009e;
import java.util.Map;

/* renamed from: c.d.a.c.c.b.t */
public final /* synthetic */ class C2187t implements C3008d {

    /* renamed from: a */
    public static final C2187t f7840a = new C2187t();

    private /* synthetic */ C2187t() {
    }

    /* renamed from: a */
    public final void mo6690a(Object obj, Object obj2) {
        C2188u.m10133j((Map.Entry) obj, (C3009e) obj2);
    }
}
