package p052c.p070d.p071a.p129c.p130a;

/* renamed from: c.d.a.c.a.p */
public final /* synthetic */ class C2145p implements Runnable {

    /* renamed from: c */
    public final C2147r f7772c;

    /* renamed from: d */
    public final C2150u f7773d;

    public /* synthetic */ C2145p(C2147r rVar, C2150u uVar) {
        this.f7772c = rVar;
        this.f7773d = uVar;
    }

    public final void run() {
        this.f7772c.mo6671e(this.f7773d.f7782a);
    }
}
