package p052c.p070d.p071a.p129c.p138e;

/* renamed from: c.d.a.c.e.i */
public class C2207i<TResult> {

    /* renamed from: a */
    private final C2200c0<TResult> f7887a = new C2200c0<>();

    /* renamed from: a */
    public C2206h<TResult> mo6762a() {
        return this.f7887a;
    }

    /* renamed from: b */
    public void mo6763b(Exception exc) {
        this.f7887a.mo6754p(exc);
    }

    /* renamed from: c */
    public void mo6764c(TResult tresult) {
        this.f7887a.mo6755q(tresult);
    }

    /* renamed from: d */
    public boolean mo6765d(Exception exc) {
        return this.f7887a.mo6756r(exc);
    }

    /* renamed from: e */
    public boolean mo6766e(TResult tresult) {
        return this.f7887a.mo6757s(tresult);
    }
}
