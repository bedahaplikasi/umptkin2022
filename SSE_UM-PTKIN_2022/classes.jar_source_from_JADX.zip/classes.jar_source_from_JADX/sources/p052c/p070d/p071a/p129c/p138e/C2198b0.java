package p052c.p070d.p071a.p129c.p138e;

import java.util.concurrent.Executor;

/* renamed from: c.d.a.c.e.b0 */
final class C2198b0 implements Executor {
    C2198b0() {
    }

    public final void execute(Runnable runnable) {
        runnable.run();
    }
}
