package p052c.p070d.p071a.p129c.p130a;

import android.os.Bundle;
import p052c.p070d.p071a.p129c.p138e.C2205g;
import p052c.p070d.p071a.p129c.p138e.C2206h;

/* renamed from: c.d.a.c.a.c0 */
public final /* synthetic */ class C2130c0 implements C2205g {

    /* renamed from: a */
    public static final C2130c0 f7744a = new C2130c0();

    private /* synthetic */ C2130c0() {
    }

    /* renamed from: a */
    public final C2206h mo6642a(Object obj) {
        return C2131d.m10069b((Bundle) obj);
    }
}
