package p052c.p070d.p071a.p129c.p134c.p136b;

import com.google.firebase.messaging.p176n1.C3075b;
import com.google.firebase.p173m.C3005c;
import com.google.firebase.p173m.C3008d;
import com.google.firebase.p173m.C3009e;

/* renamed from: c.d.a.c.c.b.b */
final class C2169b implements C3008d<C3075b> {

    /* renamed from: a */
    static final C2169b f7820a = new C2169b();

    /* renamed from: b */
    private static final C3005c f7821b;

    static {
        C3005c.C3007b a = C3005c.m13127a("messagingClientEvent");
        C2182o oVar = new C2182o();
        oVar.mo6709a(1);
        a.mo8428b(oVar.mo6710b());
        f7821b = a.mo8427a();
    }

    private C2169b() {
    }

    /* renamed from: a */
    public final /* bridge */ /* synthetic */ void mo6690a(Object obj, Object obj2) {
        ((C3009e) obj2).mo6720e(f7821b, ((C3075b) obj).mo8602a());
    }
}
