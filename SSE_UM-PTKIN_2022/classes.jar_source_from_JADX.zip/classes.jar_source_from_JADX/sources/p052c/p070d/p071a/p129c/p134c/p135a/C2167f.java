package p052c.p070d.p071a.p129c.p134c.p135a;

import android.os.Handler;
import android.os.Looper;

/* renamed from: c.d.a.c.c.a.f */
public class C2167f extends Handler {
    public C2167f(Looper looper) {
        super(looper);
    }

    public C2167f(Looper looper, Handler.Callback callback) {
        super(looper, callback);
    }
}
