package p052c.p070d.p071a.p129c.p134c.p135a;

/* renamed from: c.d.a.c.c.a.e */
public final class C2166e {

    /* renamed from: a */
    private static final C2163b f7802a;

    /* renamed from: b */
    private static volatile C2163b f7803b;

    static {
        C2165d dVar = new C2165d((C2164c) null);
        f7802a = dVar;
        f7803b = dVar;
    }

    /* renamed from: a */
    public static C2163b m10116a() {
        return f7803b;
    }
}
