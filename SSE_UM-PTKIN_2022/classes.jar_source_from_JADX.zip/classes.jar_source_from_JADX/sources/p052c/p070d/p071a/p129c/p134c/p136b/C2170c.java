package p052c.p070d.p071a.p129c.p134c.p136b;

import com.google.firebase.p173m.C3005c;
import com.google.firebase.p173m.C3008d;
import com.google.firebase.p173m.C3009e;

/* renamed from: c.d.a.c.c.b.c */
final class C2170c implements C3008d<C2172e> {

    /* renamed from: a */
    static final C2170c f7822a = new C2170c();

    /* renamed from: b */
    private static final C3005c f7823b = C3005c.m13128d("messagingClientEventExtension");

    private C2170c() {
    }

    /* renamed from: a */
    public final /* bridge */ /* synthetic */ void mo6690a(Object obj, Object obj2) {
        ((C3009e) obj2).mo6720e(f7823b, ((C2172e) obj).mo6692a());
    }
}
