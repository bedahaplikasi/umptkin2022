package p052c.p070d.p071a.p129c.p134c.p136b;

import com.google.firebase.messaging.p176n1.C3070a;
import com.google.firebase.p173m.C3005c;
import com.google.firebase.p173m.C3008d;
import com.google.firebase.p173m.C3009e;

/* renamed from: c.d.a.c.c.b.a */
final class C2168a implements C3008d<C3070a> {

    /* renamed from: a */
    static final C2168a f7804a = new C2168a();

    /* renamed from: b */
    private static final C3005c f7805b;

    /* renamed from: c */
    private static final C3005c f7806c;

    /* renamed from: d */
    private static final C3005c f7807d;

    /* renamed from: e */
    private static final C3005c f7808e;

    /* renamed from: f */
    private static final C3005c f7809f;

    /* renamed from: g */
    private static final C3005c f7810g;

    /* renamed from: h */
    private static final C3005c f7811h;

    /* renamed from: i */
    private static final C3005c f7812i;

    /* renamed from: j */
    private static final C3005c f7813j;

    /* renamed from: k */
    private static final C3005c f7814k;

    /* renamed from: l */
    private static final C3005c f7815l;

    /* renamed from: m */
    private static final C3005c f7816m;

    /* renamed from: n */
    private static final C3005c f7817n;

    /* renamed from: o */
    private static final C3005c f7818o;

    /* renamed from: p */
    private static final C3005c f7819p;

    static {
        C3005c.C3007b a = C3005c.m13127a("projectNumber");
        C2182o oVar = new C2182o();
        oVar.mo6709a(1);
        a.mo8428b(oVar.mo6710b());
        f7805b = a.mo8427a();
        C3005c.C3007b a2 = C3005c.m13127a("messageId");
        C2182o oVar2 = new C2182o();
        oVar2.mo6709a(2);
        a2.mo8428b(oVar2.mo6710b());
        f7806c = a2.mo8427a();
        C3005c.C3007b a3 = C3005c.m13127a("instanceId");
        C2182o oVar3 = new C2182o();
        oVar3.mo6709a(3);
        a3.mo8428b(oVar3.mo6710b());
        f7807d = a3.mo8427a();
        C3005c.C3007b a4 = C3005c.m13127a("messageType");
        C2182o oVar4 = new C2182o();
        oVar4.mo6709a(4);
        a4.mo8428b(oVar4.mo6710b());
        f7808e = a4.mo8427a();
        C3005c.C3007b a5 = C3005c.m13127a("sdkPlatform");
        C2182o oVar5 = new C2182o();
        oVar5.mo6709a(5);
        a5.mo8428b(oVar5.mo6710b());
        f7809f = a5.mo8427a();
        C3005c.C3007b a6 = C3005c.m13127a("packageName");
        C2182o oVar6 = new C2182o();
        oVar6.mo6709a(6);
        a6.mo8428b(oVar6.mo6710b());
        f7810g = a6.mo8427a();
        C3005c.C3007b a7 = C3005c.m13127a("collapseKey");
        C2182o oVar7 = new C2182o();
        oVar7.mo6709a(7);
        a7.mo8428b(oVar7.mo6710b());
        f7811h = a7.mo8427a();
        C3005c.C3007b a8 = C3005c.m13127a("priority");
        C2182o oVar8 = new C2182o();
        oVar8.mo6709a(8);
        a8.mo8428b(oVar8.mo6710b());
        f7812i = a8.mo8427a();
        C3005c.C3007b a9 = C3005c.m13127a("ttl");
        C2182o oVar9 = new C2182o();
        oVar9.mo6709a(9);
        a9.mo8428b(oVar9.mo6710b());
        f7813j = a9.mo8427a();
        C3005c.C3007b a10 = C3005c.m13127a("topic");
        C2182o oVar10 = new C2182o();
        oVar10.mo6709a(10);
        a10.mo8428b(oVar10.mo6710b());
        f7814k = a10.mo8427a();
        C3005c.C3007b a11 = C3005c.m13127a("bulkId");
        C2182o oVar11 = new C2182o();
        oVar11.mo6709a(11);
        a11.mo8428b(oVar11.mo6710b());
        f7815l = a11.mo8427a();
        C3005c.C3007b a12 = C3005c.m13127a("event");
        C2182o oVar12 = new C2182o();
        oVar12.mo6709a(12);
        a12.mo8428b(oVar12.mo6710b());
        f7816m = a12.mo8427a();
        C3005c.C3007b a13 = C3005c.m13127a("analyticsLabel");
        C2182o oVar13 = new C2182o();
        oVar13.mo6709a(13);
        a13.mo8428b(oVar13.mo6710b());
        f7817n = a13.mo8427a();
        C3005c.C3007b a14 = C3005c.m13127a("campaignId");
        C2182o oVar14 = new C2182o();
        oVar14.mo6709a(14);
        a14.mo8428b(oVar14.mo6710b());
        f7818o = a14.mo8427a();
        C3005c.C3007b a15 = C3005c.m13127a("composerLabel");
        C2182o oVar15 = new C2182o();
        oVar15.mo6709a(15);
        a15.mo8428b(oVar15.mo6710b());
        f7819p = a15.mo8427a();
    }

    private C2168a() {
    }

    /* renamed from: a */
    public final /* bridge */ /* synthetic */ void mo6690a(Object obj, Object obj2) {
        C3070a aVar = (C3070a) obj;
        C3009e eVar = (C3009e) obj2;
        eVar.mo6716a(f7805b, aVar.mo8585l());
        eVar.mo6720e(f7806c, aVar.mo8581h());
        eVar.mo6720e(f7807d, aVar.mo8580g());
        eVar.mo6720e(f7808e, aVar.mo8582i());
        eVar.mo6720e(f7809f, aVar.mo8586m());
        eVar.mo6720e(f7810g, aVar.mo8583j());
        eVar.mo6720e(f7811h, aVar.mo8577d());
        eVar.mo6717b(f7812i, aVar.mo8584k());
        eVar.mo6717b(f7813j, aVar.mo8588o());
        eVar.mo6720e(f7814k, aVar.mo8587n());
        eVar.mo6716a(f7815l, aVar.mo8575b());
        eVar.mo6720e(f7816m, aVar.mo8579f());
        eVar.mo6720e(f7817n, aVar.mo8574a());
        eVar.mo6716a(f7818o, aVar.mo8576c());
        eVar.mo6720e(f7819p, aVar.mo8578e());
    }
}
