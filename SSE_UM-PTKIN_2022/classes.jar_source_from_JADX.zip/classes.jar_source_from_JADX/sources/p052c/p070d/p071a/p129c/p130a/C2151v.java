package p052c.p070d.p071a.p129c.p130a;

/* renamed from: c.d.a.c.a.v */
public final class C2151v extends Exception {
    C2151v(int i, String str, Throwable th) {
        super(str, th);
    }
}
