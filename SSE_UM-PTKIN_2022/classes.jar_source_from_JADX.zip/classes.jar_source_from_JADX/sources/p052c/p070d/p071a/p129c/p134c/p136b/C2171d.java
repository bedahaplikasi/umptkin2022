package p052c.p070d.p071a.p129c.p134c.p136b;

import com.google.firebase.messaging.p176n1.C3070a;
import com.google.firebase.messaging.p176n1.C3075b;
import com.google.firebase.p173m.p174h.C3012a;
import com.google.firebase.p173m.p174h.C3013b;

/* renamed from: c.d.a.c.c.b.d */
public final class C2171d implements C3012a {

    /* renamed from: a */
    public static final C3012a f7824a = new C2171d();

    private C2171d() {
    }

    /* renamed from: a */
    public final void mo6691a(C3013b<?> bVar) {
        bVar.mo6725a(C2172e.class, C2170c.f7822a);
        bVar.mo6725a(C3075b.class, C2169b.f7820a);
        bVar.mo6725a(C3070a.class, C2168a.f7804a);
    }
}
