package p052c.p070d.p071a.p129c.p138e;

/* renamed from: c.d.a.c.e.c */
public interface C2199c<TResult> {
    /* renamed from: a */
    void mo6639a(C2206h<TResult> hVar);
}
