package p052c.p070d.p071a.p129c.p130a;

/* renamed from: c.d.a.c.a.l */
public final /* synthetic */ class C2141l implements Runnable {

    /* renamed from: c */
    public final C2147r f7767c;

    public /* synthetic */ C2141l(C2147r rVar) {
        this.f7767c = rVar;
    }

    public final void run() {
        this.f7767c.mo6667a(2, "Service disconnected");
    }
}
