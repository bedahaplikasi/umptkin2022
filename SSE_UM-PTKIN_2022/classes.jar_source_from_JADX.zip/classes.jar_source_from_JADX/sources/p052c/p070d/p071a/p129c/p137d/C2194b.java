package p052c.p070d.p071a.p129c.p137d;

/* renamed from: c.d.a.c.d.b */
final class C2194b implements Runnable {

    /* renamed from: c */
    private final C2193a f7875c;

    C2194b(C2193a aVar) {
        this.f7875c = aVar;
    }

    public final void run() {
        this.f7875c.m10161f(0);
    }
}
