package p052c.p070d.p071a.p129c.p134c.p136b;

/* renamed from: c.d.a.c.c.b.q */
public interface C2184q {
    /* renamed from: a */
    int mo6715a();
}
