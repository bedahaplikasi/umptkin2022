package p052c.p070d.p071a.p129c.p138e;

/* renamed from: c.d.a.c.e.f */
public class C2204f extends RuntimeException {
    public C2204f(Throwable th) {
        super(th);
    }
}
