package p052c.p070d.p071a.p129c.p130a;

import android.os.Bundle;

/* renamed from: c.d.a.c.a.w */
final class C2152w extends C2150u<Bundle> {
    C2152w(int i, int i2, Bundle bundle) {
        super(i, 1, bundle);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public final void mo6677a(Bundle bundle) {
        Bundle bundle2 = bundle.getBundle("data");
        if (bundle2 == null) {
            bundle2 = Bundle.EMPTY;
        }
        mo6680d(bundle2);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public final boolean mo6678b() {
        return false;
    }
}
