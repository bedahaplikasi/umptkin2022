package p052c.p070d.p071a.p129c.p134c.p136b;

/* renamed from: c.d.a.c.c.b.i */
public final class C2176i {

    /* renamed from: a */
    private static final C2173f f7826a;

    /* renamed from: b */
    private static volatile C2173f f7827b;

    static {
        C2175h hVar = new C2175h((C2174g) null);
        f7826a = hVar;
        f7827b = hVar;
    }

    /* renamed from: a */
    public static C2173f m10123a() {
        return f7827b;
    }
}
