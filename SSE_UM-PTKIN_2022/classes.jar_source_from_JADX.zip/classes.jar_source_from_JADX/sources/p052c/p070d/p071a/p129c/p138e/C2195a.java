package p052c.p070d.p071a.p129c.p138e;

/* renamed from: c.d.a.c.e.a */
public interface C2195a<TResult, TContinuationResult> {
    /* renamed from: a */
    TContinuationResult mo6633a(C2206h<TResult> hVar);
}
