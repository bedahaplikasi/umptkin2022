package p052c.p070d.p071a.p129c.p131b;

/* renamed from: c.d.a.c.b.a */
public final class C2156a {

    /* renamed from: a */
    public static final int f7796a = 2131558428;
}
