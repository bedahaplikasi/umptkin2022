package p052c.p070d.p071a.p129c.p134c.p136b;

import com.google.firebase.p173m.C3004b;
import com.google.firebase.p173m.C3008d;
import com.google.firebase.p173m.C3009e;

/* renamed from: c.d.a.c.c.b.v */
public final /* synthetic */ class C2189v implements C3008d {

    /* renamed from: a */
    public static final C2189v f7850a = new C2189v();

    private /* synthetic */ C2189v() {
    }

    /* renamed from: a */
    public final void mo6690a(Object obj, Object obj2) {
        C3009e eVar = (C3009e) obj2;
        int i = C2190w.f7852e;
        String valueOf = String.valueOf(obj.getClass().getCanonicalName());
        throw new C3004b(valueOf.length() != 0 ? "Couldn't find encoder for type ".concat(valueOf) : new String("Couldn't find encoder for type "));
    }
}
