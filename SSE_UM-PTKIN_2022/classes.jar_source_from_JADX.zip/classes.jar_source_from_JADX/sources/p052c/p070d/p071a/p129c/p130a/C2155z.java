package p052c.p070d.p071a.p129c.p130a;

import android.os.Bundle;
import p052c.p070d.p071a.p129c.p138e.C2195a;
import p052c.p070d.p071a.p129c.p138e.C2206h;

/* renamed from: c.d.a.c.a.z */
public final /* synthetic */ class C2155z implements C2195a {

    /* renamed from: a */
    public final C2131d f7794a;

    /* renamed from: b */
    public final Bundle f7795b;

    public /* synthetic */ C2155z(C2131d dVar, Bundle bundle) {
        this.f7794a = dVar;
        this.f7795b = bundle;
    }

    /* renamed from: a */
    public final Object mo6633a(C2206h hVar) {
        return this.f7794a.mo6644c(this.f7795b, hVar);
    }
}
