package p052c.p070d.p071a.p129c.p130a;

import android.os.Looper;
import android.os.Message;
import p052c.p070d.p071a.p129c.p134c.p135a.C2167f;

/* renamed from: c.d.a.c.a.f */
final class C2135f extends C2167f {

    /* renamed from: a */
    final C2131d f7758a;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    C2135f(C2131d dVar, Looper looper) {
        super(looper);
        this.f7758a = dVar;
    }

    public final void handleMessage(Message message) {
        C2131d.m10070d(this.f7758a, message);
    }
}
