package p052c.p070d.p071a.p129c.p130a;

import java.util.concurrent.Executor;

/* renamed from: c.d.a.c.a.e0 */
public final /* synthetic */ class C2134e0 implements Executor {

    /* renamed from: a */
    public static final C2134e0 f7757a = new C2134e0();

    private /* synthetic */ C2134e0() {
    }

    public final void execute(Runnable runnable) {
        runnable.run();
    }
}
