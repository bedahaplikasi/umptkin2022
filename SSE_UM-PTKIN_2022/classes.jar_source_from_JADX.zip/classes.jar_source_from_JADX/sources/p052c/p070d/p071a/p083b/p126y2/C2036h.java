package p052c.p070d.p071a.p083b.p126y2;

import android.os.Handler;
import android.os.Looper;

/* renamed from: c.d.a.b.y2.h */
public interface C2036h {

    /* renamed from: a */
    public static final C2036h f7476a = new C2039i0();

    /* renamed from: a */
    long mo6446a();

    /* renamed from: b */
    C2062r mo6447b(Looper looper, Handler.Callback callback);

    /* renamed from: c */
    void mo6448c();

    /* renamed from: d */
    long mo6449d();
}
