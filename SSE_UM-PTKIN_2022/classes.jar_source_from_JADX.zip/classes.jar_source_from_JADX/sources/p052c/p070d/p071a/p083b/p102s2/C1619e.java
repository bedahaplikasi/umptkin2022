package p052c.p070d.p071a.p083b.p102s2;

import p052c.p070d.p071a.p083b.p086n2.C1265f;

/* renamed from: c.d.a.b.s2.e */
public final class C1619e extends C1265f {

    /* renamed from: k */
    public long f6061k;

    public C1619e() {
        super(1);
    }
}
