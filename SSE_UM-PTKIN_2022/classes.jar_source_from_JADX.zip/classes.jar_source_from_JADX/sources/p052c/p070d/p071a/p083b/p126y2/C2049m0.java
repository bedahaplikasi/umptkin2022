package p052c.p070d.p071a.p083b.p126y2;

import android.os.Trace;

/* renamed from: c.d.a.b.y2.m0 */
public final class C2049m0 {
    /* renamed from: a */
    public static void m9642a(String str) {
        if (C2058o0.f7516a >= 18) {
            m9643b(str);
        }
    }

    /* renamed from: b */
    private static void m9643b(String str) {
        Trace.beginSection(str);
    }

    /* renamed from: c */
    public static void m9644c() {
        if (C2058o0.f7516a >= 18) {
            m9645d();
        }
    }

    /* renamed from: d */
    private static void m9645d() {
        Trace.endSection();
    }
}
