package p052c.p070d.p071a.p083b.p089q2.p094i0;

import p052c.p070d.p071a.p083b.p089q2.C1430k;

/* renamed from: c.d.a.b.q2.i0.c */
public interface C1410c {
    /* renamed from: a */
    void mo5175a(int i);

    /* renamed from: b */
    int mo5176b(int i);

    /* renamed from: c */
    void mo5177c(int i, double d);

    /* renamed from: d */
    boolean mo5178d(int i);

    /* renamed from: e */
    void mo5179e(int i, int i2, C1430k kVar);

    /* renamed from: f */
    void mo5180f(int i, String str);

    /* renamed from: g */
    void mo5181g(int i, long j, long j2);

    /* renamed from: h */
    void mo5182h(int i, long j);
}
