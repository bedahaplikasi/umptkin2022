package p052c.p070d.p071a.p083b.p089q2.p096k0;

/* renamed from: c.d.a.b.q2.k0.g */
final class C1445g {

    /* renamed from: a */
    public final int f5213a;

    /* renamed from: b */
    public final int f5214b;

    /* renamed from: c */
    public final int f5215c;

    /* renamed from: d */
    public final int f5216d;

    public C1445g(int i, int i2, int i3, int i4) {
        this.f5213a = i;
        this.f5214b = i2;
        this.f5215c = i3;
        this.f5216d = i4;
    }
}
