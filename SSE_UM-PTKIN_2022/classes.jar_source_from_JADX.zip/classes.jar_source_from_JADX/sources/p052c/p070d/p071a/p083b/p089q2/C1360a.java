package p052c.p070d.p071a.p083b.p089q2;

import android.net.Uri;
import java.util.Map;

/* renamed from: c.d.a.b.q2.a */
public final /* synthetic */ class C1360a implements C1540o {

    /* renamed from: a */
    public static final C1360a f4838a = new C1360a();

    private /* synthetic */ C1360a() {
    }

    /* renamed from: a */
    public final C1419j[] mo5109a() {
        return C1485n.m7024b();
    }

    /* renamed from: b */
    public /* synthetic */ C1419j[] mo5110b(Uri uri, Map map) {
        return C1485n.m7023a(this, uri, map);
    }
}
