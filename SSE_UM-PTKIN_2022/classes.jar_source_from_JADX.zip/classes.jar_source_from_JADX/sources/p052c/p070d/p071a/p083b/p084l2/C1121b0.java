package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.b0 */
public final /* synthetic */ class C1121b0 implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4116a;

    /* renamed from: b */
    public final int f4117b;

    public /* synthetic */ C1121b0(C1138g1.C1139a aVar, int i) {
        this.f4116a = aVar;
        this.f4117b = i;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        C1134f1.m5219M0(this.f4116a, this.f4117b, (C1138g1) obj);
    }
}
