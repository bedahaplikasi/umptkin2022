package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p085m2.C1230p;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.d1 */
public final /* synthetic */ class C1128d1 implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4135a;

    /* renamed from: b */
    public final C1230p f4136b;

    public /* synthetic */ C1128d1(C1138g1.C1139a aVar, C1230p pVar) {
        this.f4135a = aVar;
        this.f4136b = pVar;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        ((C1138g1) obj).mo4659X(this.f4135a, this.f4136b);
    }
}
