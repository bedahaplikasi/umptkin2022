package p052c.p070d.p071a.p083b.p089q2;

import android.net.Uri;
import java.util.List;
import java.util.Map;

/* renamed from: c.d.a.b.q2.o */
public interface C1540o {
    static {
        C1360a aVar = C1360a.f4838a;
    }

    /* renamed from: a */
    C1419j[] mo5109a();

    /* renamed from: b */
    C1419j[] mo5110b(Uri uri, Map<String, List<String>> map);
}
