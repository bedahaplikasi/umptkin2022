package p052c.p070d.p071a.p083b.p124w2;

import java.util.List;
import p052c.p070d.p071a.p083b.p111u2.p113w0.C1792f;

/* renamed from: c.d.a.b.w2.g */
public final /* synthetic */ class C1923g {
    /* renamed from: a */
    public static void m9174a(C1924h hVar) {
    }

    /* renamed from: b */
    public static void m9175b(C1924h hVar, boolean z) {
    }

    /* renamed from: c */
    public static void m9176c(C1924h hVar) {
    }

    /* renamed from: d */
    public static boolean m9177d(C1924h hVar, long j, C1792f fVar, List list) {
        return false;
    }
}
