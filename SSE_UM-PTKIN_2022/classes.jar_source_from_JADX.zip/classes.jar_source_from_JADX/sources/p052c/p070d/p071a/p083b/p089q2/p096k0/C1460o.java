package p052c.p070d.p071a.p083b.p089q2.p096k0;

import p052c.p070d.p071a.p083b.C1067e1;

/* renamed from: c.d.a.b.q2.k0.o */
public final class C1460o {

    /* renamed from: a */
    public final int f5313a;

    /* renamed from: b */
    public final int f5314b;

    /* renamed from: c */
    public final long f5315c;

    /* renamed from: d */
    public final long f5316d;

    /* renamed from: e */
    public final long f5317e;

    /* renamed from: f */
    public final C1067e1 f5318f;

    /* renamed from: g */
    public final int f5319g;

    /* renamed from: h */
    public final long[] f5320h;

    /* renamed from: i */
    public final long[] f5321i;

    /* renamed from: j */
    public final int f5322j;

    /* renamed from: k */
    private final C1461p[] f5323k;

    public C1460o(int i, int i2, long j, long j2, long j3, C1067e1 e1Var, int i3, C1461p[] pVarArr, int i4, long[] jArr, long[] jArr2) {
        this.f5313a = i;
        this.f5314b = i2;
        this.f5315c = j;
        this.f5316d = j2;
        this.f5317e = j3;
        this.f5318f = e1Var;
        this.f5319g = i3;
        this.f5323k = pVarArr;
        this.f5322j = i4;
        this.f5320h = jArr;
        this.f5321i = jArr2;
    }

    /* renamed from: a */
    public C1461p mo5236a(int i) {
        C1461p[] pVarArr = this.f5323k;
        if (pVarArr == null) {
            return null;
        }
        return pVarArr[i];
    }
}
