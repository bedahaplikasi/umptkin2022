package p052c.p070d.p071a.p083b.p102s2.p109o;

import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: c.d.a.b.s2.o.e */
public final class C1684e extends C1679b {
    public static final Parcelable.Creator<C1684e> CREATOR = new C1685a();

    /* renamed from: c.d.a.b.s2.o.e$a */
    class C1685a implements Parcelable.Creator<C1684e> {
        C1685a() {
        }

        /* renamed from: a */
        public C1684e createFromParcel(Parcel parcel) {
            return new C1684e();
        }

        /* renamed from: b */
        public C1684e[] newArray(int i) {
            return new C1684e[i];
        }
    }

    public void writeToParcel(Parcel parcel, int i) {
    }
}
