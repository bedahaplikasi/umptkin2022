package p052c.p070d.p071a.p083b.p126y2;

import java.util.concurrent.ThreadFactory;

/* renamed from: c.d.a.b.y2.f */
public final /* synthetic */ class C2026f implements ThreadFactory {

    /* renamed from: a */
    public final String f7457a;

    public /* synthetic */ C2026f(String str) {
        this.f7457a = str;
    }

    public final Thread newThread(Runnable runnable) {
        return C2058o0.m9734n0(this.f7457a, runnable);
    }
}
