package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.n */
public final /* synthetic */ class C1153n implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4205a;

    /* renamed from: b */
    public final boolean f4206b;

    public /* synthetic */ C1153n(C1138g1.C1139a aVar, boolean z) {
        this.f4205a = aVar;
        this.f4206b = z;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        C1134f1.m5223Q0(this.f4205a, this.f4206b, (C1138g1) obj);
    }
}
