package p052c.p070d.p071a.p083b.p089q2.p100o0;

import android.net.Uri;
import java.util.Map;
import p052c.p070d.p071a.p083b.p089q2.C1419j;
import p052c.p070d.p071a.p083b.p089q2.C1485n;
import p052c.p070d.p071a.p083b.p089q2.C1540o;

/* renamed from: c.d.a.b.q2.o0.a */
public final /* synthetic */ class C1541a implements C1540o {

    /* renamed from: a */
    public static final C1541a f5788a = new C1541a();

    private /* synthetic */ C1541a() {
    }

    /* renamed from: a */
    public final C1419j[] mo5109a() {
        return C1542b.m7326e();
    }

    /* renamed from: b */
    public /* synthetic */ C1419j[] mo5110b(Uri uri, Map map) {
        return C1485n.m7023a(this, uri, map);
    }
}
