package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.C1939x0;
import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.d */
public final /* synthetic */ class C1126d implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4129a;

    /* renamed from: b */
    public final C1939x0 f4130b;

    public /* synthetic */ C1126d(C1138g1.C1139a aVar, C1939x0 x0Var) {
        this.f4129a = aVar;
        this.f4130b = x0Var;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        ((C1138g1) obj).mo4693p0(this.f4129a, this.f4130b);
    }
}
