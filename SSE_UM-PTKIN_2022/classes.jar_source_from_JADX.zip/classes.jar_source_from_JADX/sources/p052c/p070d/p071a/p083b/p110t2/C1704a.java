package p052c.p070d.p071a.p083b.p110t2;

import java.util.List;

/* renamed from: c.d.a.b.t2.a */
public interface C1704a<T> {
    /* renamed from: a */
    T mo5704a(List<C1706c> list);
}
