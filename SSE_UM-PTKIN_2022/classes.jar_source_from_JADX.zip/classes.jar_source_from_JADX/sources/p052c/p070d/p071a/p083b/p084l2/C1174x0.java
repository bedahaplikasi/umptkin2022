package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.x0 */
public final /* synthetic */ class C1174x0 implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4251a;

    /* renamed from: b */
    public final long f4252b;

    /* renamed from: c */
    public final int f4253c;

    public /* synthetic */ C1174x0(C1138g1.C1139a aVar, long j, int i) {
        this.f4251a = aVar;
        this.f4252b = j;
        this.f4253c = i;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        ((C1138g1) obj).mo4690o(this.f4251a, this.f4252b, this.f4253c);
    }
}
