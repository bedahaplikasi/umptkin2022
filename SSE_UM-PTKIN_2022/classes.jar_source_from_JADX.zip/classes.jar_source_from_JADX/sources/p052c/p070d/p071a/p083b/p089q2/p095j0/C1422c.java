package p052c.p070d.p071a.p083b.p089q2.p095j0;

import p052c.p070d.p071a.p083b.p085m2.C1207g0;
import p052c.p070d.p071a.p083b.p089q2.C1382f;

/* renamed from: c.d.a.b.q2.j0.c */
final class C1422c extends C1382f implements C1426g {
    public C1422c(long j, long j2, C1207g0.C1208a aVar) {
        super(j, j2, aVar.f4409f, aVar.f4406c);
    }

    /* renamed from: b */
    public long mo5205b(long j) {
        return mo5146c(j);
    }

    /* renamed from: e */
    public long mo5206e() {
        return -1;
    }
}
