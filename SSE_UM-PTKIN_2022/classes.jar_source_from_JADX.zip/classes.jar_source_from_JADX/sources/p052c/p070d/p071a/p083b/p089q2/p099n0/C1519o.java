package p052c.p070d.p071a.p083b.p089q2.p099n0;

import p052c.p070d.p071a.p083b.p089q2.C1464l;
import p052c.p070d.p071a.p083b.p089q2.p099n0.C1507i0;
import p052c.p070d.p071a.p083b.p126y2.C2021c0;

/* renamed from: c.d.a.b.q2.n0.o */
public interface C1519o {
    /* renamed from: a */
    void mo5284a();

    /* renamed from: c */
    void mo5285c(C2021c0 c0Var);

    /* renamed from: d */
    void mo5286d();

    /* renamed from: e */
    void mo5287e(long j, int i);

    /* renamed from: f */
    void mo5288f(C1464l lVar, C1507i0.C1511d dVar);
}
