package p052c.p070d.p071a.p083b.p126y2;

import p052c.p070d.p071a.p083b.C1611s1;

/* renamed from: c.d.a.b.y2.w */
public interface C2071w {
    /* renamed from: h */
    C1611s1 mo4802h();

    /* renamed from: i */
    void mo4803i(C1611s1 s1Var);

    /* renamed from: z */
    long mo4809z();
}
