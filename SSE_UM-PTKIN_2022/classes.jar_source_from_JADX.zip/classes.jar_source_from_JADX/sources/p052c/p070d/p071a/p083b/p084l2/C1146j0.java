package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p111u2.C1776t0;
import p052c.p070d.p071a.p083b.p124w2.C1931l;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.j0 */
public final /* synthetic */ class C1146j0 implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4187a;

    /* renamed from: b */
    public final C1776t0 f4188b;

    /* renamed from: c */
    public final C1931l f4189c;

    public /* synthetic */ C1146j0(C1138g1.C1139a aVar, C1776t0 t0Var, C1931l lVar) {
        this.f4187a = aVar;
        this.f4188b = t0Var;
        this.f4189c = lVar;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        ((C1138g1) obj).mo4687m0(this.f4187a, this.f4188b, this.f4189c);
    }
}
