package p052c.p070d.p071a.p083b.p102s2;

/* renamed from: c.d.a.b.s2.f */
public interface C1620f {
    /* renamed from: c0 */
    void mo4437c0(C1612a aVar);
}
