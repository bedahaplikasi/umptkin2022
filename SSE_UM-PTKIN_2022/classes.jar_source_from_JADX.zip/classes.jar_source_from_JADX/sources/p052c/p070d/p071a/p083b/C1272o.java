package p052c.p070d.p071a.p083b;

import p052c.p070d.p071a.p083b.C1696t1;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.o */
public final /* synthetic */ class C1272o implements C2065t.C2066a {

    /* renamed from: a */
    public final C1110k1 f4645a;

    public /* synthetic */ C1272o(C1110k1 k1Var) {
        this.f4645a = k1Var;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        ((C1696t1.C1700c) obj).mo4431Y(this.f4645a);
    }
}
