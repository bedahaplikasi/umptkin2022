package p052c.p070d.p071a.p083b.p089q2.p099n0;

import android.net.Uri;
import java.util.Map;
import p052c.p070d.p071a.p083b.p089q2.C1419j;
import p052c.p070d.p071a.p083b.p089q2.C1485n;
import p052c.p070d.p071a.p083b.p089q2.C1540o;

/* renamed from: c.d.a.b.q2.n0.b */
public final /* synthetic */ class C1488b implements C1540o {

    /* renamed from: a */
    public static final C1488b f5436a = new C1488b();

    private /* synthetic */ C1488b() {
    }

    /* renamed from: a */
    public final C1419j[] mo5109a() {
        return C1502h.m7092b();
    }

    /* renamed from: b */
    public /* synthetic */ C1419j[] mo5110b(Uri uri, Map map) {
        return C1485n.m7023a(this, uri, map);
    }
}
