package p052c.p070d.p071a.p083b.p089q2.p096k0;

import android.net.Uri;
import java.util.Map;
import p052c.p070d.p071a.p083b.p089q2.C1419j;
import p052c.p070d.p071a.p083b.p089q2.C1485n;
import p052c.p070d.p071a.p083b.p089q2.C1540o;

/* renamed from: c.d.a.b.q2.k0.c */
public final /* synthetic */ class C1433c implements C1540o {

    /* renamed from: a */
    public static final C1433c f5181a = new C1433c();

    private /* synthetic */ C1433c() {
    }

    /* renamed from: a */
    public final C1419j[] mo5109a() {
        return C1453k.m6880q();
    }

    /* renamed from: b */
    public /* synthetic */ C1419j[] mo5110b(Uri uri, Map map) {
        return C1485n.m7023a(this, uri, map);
    }
}
