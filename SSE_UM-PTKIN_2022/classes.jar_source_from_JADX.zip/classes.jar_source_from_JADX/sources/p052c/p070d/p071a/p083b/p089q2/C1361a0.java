package p052c.p070d.p071a.p083b.p089q2;

import p052c.p070d.p071a.p083b.p125x2.C1979k;
import p052c.p070d.p071a.p083b.p126y2.C2021c0;

/* renamed from: c.d.a.b.q2.a0 */
public final /* synthetic */ class C1361a0 {
    /* renamed from: a */
    public static int m6357a(C1369b0 b0Var, C1979k kVar, int i, boolean z) {
        return b0Var.mo5128b(kVar, i, z, 0);
    }

    /* renamed from: b */
    public static void m6358b(C1369b0 b0Var, C2021c0 c0Var, int i) {
        b0Var.mo5131e(c0Var, i, 0);
    }
}
