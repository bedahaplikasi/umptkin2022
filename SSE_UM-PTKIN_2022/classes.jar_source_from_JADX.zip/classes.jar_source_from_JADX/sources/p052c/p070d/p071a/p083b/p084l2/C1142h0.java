package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.C1696t1;
import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.h0 */
public final /* synthetic */ class C1142h0 implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4175a;

    /* renamed from: b */
    public final int f4176b;

    /* renamed from: c */
    public final C1696t1.C1703f f4177c;

    /* renamed from: d */
    public final C1696t1.C1703f f4178d;

    public /* synthetic */ C1142h0(C1138g1.C1139a aVar, int i, C1696t1.C1703f fVar, C1696t1.C1703f fVar2) {
        this.f4175a = aVar;
        this.f4176b = i;
        this.f4177c = fVar;
        this.f4178d = fVar2;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        C1134f1.m5238f1(this.f4175a, this.f4176b, this.f4177c, this.f4178d, (C1138g1) obj);
    }
}
