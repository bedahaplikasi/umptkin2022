package p052c.p070d.p071a.p083b;

/* renamed from: c.d.a.b.c2 */
public interface C1060c2 {
    /* renamed from: a */
    String mo4330a();

    /* renamed from: b */
    int mo4331b(C1067e1 e1Var);

    /* renamed from: j */
    int mo4332j();

    /* renamed from: n */
    int mo4333n();
}
