package p052c.p070d.p071a.p083b.p085m2;

import p052c.p070d.p071a.p083b.C1067e1;

/* renamed from: c.d.a.b.m2.u */
public final /* synthetic */ class C1239u {
    @Deprecated
    /* renamed from: a */
    public static void m5792a(C1240v vVar, C1067e1 e1Var) {
    }
}
