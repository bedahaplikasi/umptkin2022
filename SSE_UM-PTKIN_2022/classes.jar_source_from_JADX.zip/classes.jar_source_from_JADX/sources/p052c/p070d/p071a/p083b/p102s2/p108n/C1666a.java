package p052c.p070d.p071a.p083b.p102s2.p108n;

import java.util.Comparator;
import p052c.p070d.p071a.p083b.p102s2.p108n.C1671d;
import p052c.p070d.p139b.p141b.C2320m;

/* renamed from: c.d.a.b.s2.n.a */
public final /* synthetic */ class C1666a implements Comparator {

    /* renamed from: c */
    public static final C1666a f6150c = new C1666a();

    private /* synthetic */ C1666a() {
    }

    public final int compare(Object obj, Object obj2) {
        return C2320m.m10495j().mo7068e(((C1671d.C1673b) obj).f6161c, ((C1671d.C1673b) obj2).f6161c).mo7068e(((C1671d.C1673b) obj).f6162d, ((C1671d.C1673b) obj2).f6162d).mo7067d(((C1671d.C1673b) obj).f6163e, ((C1671d.C1673b) obj2).f6163e).mo7072i();
    }
}
