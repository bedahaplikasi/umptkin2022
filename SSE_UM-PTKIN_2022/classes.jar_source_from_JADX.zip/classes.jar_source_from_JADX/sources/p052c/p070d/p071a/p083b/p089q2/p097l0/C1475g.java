package p052c.p070d.p071a.p083b.p089q2.p097l0;

import p052c.p070d.p071a.p083b.p089q2.C1430k;
import p052c.p070d.p071a.p083b.p089q2.C1562y;

/* renamed from: c.d.a.b.q2.l0.g */
interface C1475g {
    /* renamed from: a */
    C1562y mo5246a();

    /* renamed from: b */
    long mo5247b(C1430k kVar);

    /* renamed from: c */
    void mo5248c(long j);
}
