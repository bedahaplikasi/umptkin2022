package p052c.p070d.p071a.p083b.p102s2;

/* renamed from: c.d.a.b.s2.c */
public interface C1616c {
    /* renamed from: a */
    C1612a mo5481a(C1619e eVar);
}
