package p052c.p070d.p071a.p083b.p114v2.p123u;

import java.util.Comparator;
import p052c.p070d.p071a.p083b.p114v2.p123u.C1892h;

/* renamed from: c.d.a.b.v2.u.a */
public final /* synthetic */ class C1885a implements Comparator {

    /* renamed from: c */
    public static final C1885a f6981c = new C1885a();

    private /* synthetic */ C1885a() {
    }

    public final int compare(Object obj, Object obj2) {
        return Integer.compare(((C1892h.C1894b) obj).f7013a.f7016b, ((C1892h.C1894b) obj2).f7013a.f7016b);
    }
}
