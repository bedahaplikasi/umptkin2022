package p052c.p070d.p071a.p083b.p089q2;

/* renamed from: c.d.a.b.q2.x */
public final class C1561x {

    /* renamed from: a */
    public long f5856a;
}
