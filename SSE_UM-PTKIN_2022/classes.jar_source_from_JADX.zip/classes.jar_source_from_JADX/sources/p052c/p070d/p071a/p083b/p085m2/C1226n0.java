package p052c.p070d.p071a.p083b.p085m2;

import p052c.p070d.p071a.p083b.p126y2.C2058o0;

/* renamed from: c.d.a.b.m2.n0 */
public final class C1226n0 {
    /* renamed from: a */
    public static int m5764a(int i, int i2) {
        if (i != 1) {
            if (i == 3) {
                return i2 == 32 ? 4 : 0;
            }
            if (i != 65534) {
                return 0;
            }
        }
        return C2058o0.m9703W(i2);
    }
}
