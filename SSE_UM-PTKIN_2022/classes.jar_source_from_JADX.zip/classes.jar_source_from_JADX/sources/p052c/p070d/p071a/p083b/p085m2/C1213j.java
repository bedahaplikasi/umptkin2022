package p052c.p070d.p071a.p083b.p085m2;

import p052c.p070d.p071a.p083b.p085m2.C1240v;

/* renamed from: c.d.a.b.m2.j */
public final /* synthetic */ class C1213j implements Runnable {

    /* renamed from: c */
    public final C1240v.C1241a f4415c;

    /* renamed from: d */
    public final int f4416d;

    /* renamed from: e */
    public final long f4417e;

    /* renamed from: f */
    public final long f4418f;

    public /* synthetic */ C1213j(C1240v.C1241a aVar, int i, long j, long j2) {
        this.f4415c = aVar;
        this.f4416d = i;
        this.f4417e = j;
        this.f4418f = j2;
    }

    public final void run() {
        this.f4415c.mo4851A(this.f4416d, this.f4417e, this.f4418f);
    }
}
