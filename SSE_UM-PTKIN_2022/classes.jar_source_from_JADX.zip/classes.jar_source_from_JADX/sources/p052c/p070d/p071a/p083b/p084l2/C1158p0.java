package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p111u2.C1716b0;
import p052c.p070d.p071a.p083b.p111u2.C1810y;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.p0 */
public final /* synthetic */ class C1158p0 implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4218a;

    /* renamed from: b */
    public final C1810y f4219b;

    /* renamed from: c */
    public final C1716b0 f4220c;

    public /* synthetic */ C1158p0(C1138g1.C1139a aVar, C1810y yVar, C1716b0 b0Var) {
        this.f4218a = aVar;
        this.f4219b = yVar;
        this.f4220c = b0Var;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        ((C1138g1) obj).mo4685l0(this.f4218a, this.f4219b, this.f4220c);
    }
}
