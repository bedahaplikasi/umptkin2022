package p052c.p070d.p071a.p083b.p102s2.p107m;

import p052c.p070d.p071a.p083b.C1067e1;
import p052c.p070d.p071a.p083b.C1110k1;
import p052c.p070d.p071a.p083b.p102s2.C1612a;
import p052c.p070d.p071a.p083b.p102s2.C1615b;

/* renamed from: c.d.a.b.s2.m.i */
public abstract class C1655i implements C1612a.C1614b {

    /* renamed from: c */
    public final String f6135c;

    public C1655i(String str) {
        this.f6135c = str;
    }

    /* renamed from: a */
    public /* synthetic */ void mo5478a(C1110k1.C1112b bVar) {
        C1615b.m7747c(this, bVar);
    }

    /* renamed from: b */
    public /* synthetic */ C1067e1 mo5479b() {
        return C1615b.m7746b(this);
    }

    /* renamed from: c */
    public /* synthetic */ byte[] mo5480c() {
        return C1615b.m7745a(this);
    }

    public int describeContents() {
        return 0;
    }

    public String toString() {
        return this.f6135c;
    }
}
