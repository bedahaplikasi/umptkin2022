package p052c.p070d.p071a.p083b.p089q2;

/* renamed from: c.d.a.b.q2.j */
public interface C1419j {
    /* renamed from: a */
    void mo5141a();

    /* renamed from: c */
    void mo5142c(C1464l lVar);

    /* renamed from: d */
    void mo5143d(long j, long j2);

    /* renamed from: f */
    boolean mo5144f(C1430k kVar);

    /* renamed from: i */
    int mo5145i(C1430k kVar, C1561x xVar);
}
