package p052c.p070d.p071a.p083b.p089q2.p100o0;

/* renamed from: c.d.a.b.q2.o0.c */
final class C1546c {

    /* renamed from: a */
    public final int f5816a;

    /* renamed from: b */
    public final int f5817b;

    /* renamed from: c */
    public final int f5818c;

    /* renamed from: d */
    public final int f5819d;

    /* renamed from: e */
    public final int f5820e;

    /* renamed from: f */
    public final byte[] f5821f;

    public C1546c(int i, int i2, int i3, int i4, int i5, int i6, byte[] bArr) {
        this.f5816a = i;
        this.f5817b = i2;
        this.f5818c = i3;
        this.f5819d = i5;
        this.f5820e = i6;
        this.f5821f = bArr;
    }
}
