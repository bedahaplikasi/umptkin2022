package p052c.p070d.p071a.p083b.p126y2;

import java.util.Comparator;
import p052c.p070d.p071a.p083b.p126y2.C2027f0;

/* renamed from: c.d.a.b.y2.d */
public final /* synthetic */ class C2022d implements Comparator {

    /* renamed from: c */
    public static final C2022d f7448c = new C2022d();

    private /* synthetic */ C2022d() {
    }

    public final int compare(Object obj, Object obj2) {
        return C2027f0.m9531e((C2027f0.C2029b) obj, (C2027f0.C2029b) obj2);
    }
}
