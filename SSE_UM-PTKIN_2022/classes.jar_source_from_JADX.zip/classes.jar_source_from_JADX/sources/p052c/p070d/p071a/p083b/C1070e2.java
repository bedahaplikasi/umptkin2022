package p052c.p070d.p071a.p083b;

import android.os.Handler;
import p052c.p070d.p071a.p083b.p085m2.C1240v;
import p052c.p070d.p071a.p083b.p102s2.C1620f;
import p052c.p070d.p071a.p083b.p114v2.C1830k;
import p052c.p070d.p071a.p083b.p127z2.C2121y;

/* renamed from: c.d.a.b.e2 */
public interface C1070e2 {
    /* renamed from: a */
    C1043a2[] mo4383a(Handler handler, C2121y yVar, C1240v vVar, C1830k kVar, C1620f fVar);
}
