package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.C1611s1;
import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.b */
public final /* synthetic */ class C1120b implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4114a;

    /* renamed from: b */
    public final C1611s1 f4115b;

    public /* synthetic */ C1120b(C1138g1.C1139a aVar, C1611s1 s1Var) {
        this.f4114a = aVar;
        this.f4115b = s1Var;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        ((C1138g1) obj).mo4641F(this.f4114a, this.f4115b);
    }
}
