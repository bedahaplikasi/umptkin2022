package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p102s2.C1612a;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.h */
public final /* synthetic */ class C1141h implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4173a;

    /* renamed from: b */
    public final C1612a f4174b;

    public /* synthetic */ C1141h(C1138g1.C1139a aVar, C1612a aVar2) {
        this.f4173a = aVar;
        this.f4174b = aVar2;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        ((C1138g1) obj).mo4655T(this.f4173a, this.f4174b);
    }
}
