package p052c.p070d.p071a.p083b.p102s2.p107m;

import p052c.p070d.p071a.p083b.p102s2.p107m.C1652h;

/* renamed from: c.d.a.b.s2.m.a */
public final /* synthetic */ class C1639a implements C1652h.C1653a {

    /* renamed from: a */
    public static final C1639a f6106a = new C1639a();

    private /* synthetic */ C1639a() {
    }

    /* renamed from: a */
    public final boolean mo5204a(int i, int i2, int i3, int i4, int i5) {
        return C1652h.m7845y(i, i2, i3, i4, i5);
    }
}
