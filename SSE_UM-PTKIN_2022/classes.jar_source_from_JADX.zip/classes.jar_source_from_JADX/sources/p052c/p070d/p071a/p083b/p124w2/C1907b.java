package p052c.p070d.p071a.p083b.p124w2;

import java.util.Comparator;

/* renamed from: c.d.a.b.w2.b */
public final /* synthetic */ class C1907b implements Comparator {

    /* renamed from: c */
    public static final C1907b f7065c = new C1907b();

    private /* synthetic */ C1907b() {
    }

    public final int compare(Object obj, Object obj2) {
        return C1913f.m9139v((Integer) obj, (Integer) obj2);
    }
}
