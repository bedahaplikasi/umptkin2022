package p052c.p070d.p071a.p083b;

/* renamed from: c.d.a.b.i0 */
public final /* synthetic */ class C1091i0 implements Runnable {

    /* renamed from: c */
    public final C1086h2 f3945c;

    public /* synthetic */ C1091i0(C1086h2 h2Var) {
        this.f3945c = h2Var;
    }

    public final void run() {
        this.f3945c.m5054i();
    }
}
