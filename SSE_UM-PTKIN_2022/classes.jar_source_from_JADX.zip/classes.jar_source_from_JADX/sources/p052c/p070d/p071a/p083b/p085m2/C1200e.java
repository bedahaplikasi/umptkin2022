package p052c.p070d.p071a.p083b.p085m2;

import p052c.p070d.p071a.p083b.p085m2.C1240v;

/* renamed from: c.d.a.b.m2.e */
public final /* synthetic */ class C1200e implements Runnable {

    /* renamed from: c */
    public final C1240v.C1241a f4374c;

    /* renamed from: d */
    public final Exception f4375d;

    public /* synthetic */ C1200e(C1240v.C1241a aVar, Exception exc) {
        this.f4374c = aVar;
        this.f4375d = exc;
    }

    public final void run() {
        this.f4374c.mo4863k(this.f4375d);
    }
}
