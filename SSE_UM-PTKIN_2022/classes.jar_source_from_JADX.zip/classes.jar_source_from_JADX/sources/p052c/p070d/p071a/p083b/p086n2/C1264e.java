package p052c.p070d.p071a.p083b.p086n2;

/* renamed from: c.d.a.b.n2.e */
public class C1264e extends Exception {
    public C1264e(String str) {
        super(str);
    }

    public C1264e(String str, Throwable th) {
        super(str, th);
    }

    public C1264e(Throwable th) {
        super(th);
    }
}
