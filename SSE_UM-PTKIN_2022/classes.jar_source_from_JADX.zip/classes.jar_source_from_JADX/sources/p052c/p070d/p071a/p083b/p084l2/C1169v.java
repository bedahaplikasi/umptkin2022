package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.C1110k1;
import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.v */
public final /* synthetic */ class C1169v implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4241a;

    /* renamed from: b */
    public final C1110k1 f4242b;

    public /* synthetic */ C1169v(C1138g1.C1139a aVar, C1110k1 k1Var) {
        this.f4241a = aVar;
        this.f4242b = k1Var;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        ((C1138g1) obj).mo4646K(this.f4241a, this.f4242b);
    }
}
