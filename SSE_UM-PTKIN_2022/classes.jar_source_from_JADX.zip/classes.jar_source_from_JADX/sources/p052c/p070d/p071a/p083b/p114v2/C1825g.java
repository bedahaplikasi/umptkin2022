package p052c.p070d.p071a.p083b.p114v2;

import p052c.p070d.p071a.p083b.p086n2.C1264e;

/* renamed from: c.d.a.b.v2.g */
public class C1825g extends C1264e {
    public C1825g(String str) {
        super(str);
    }

    public C1825g(String str, Throwable th) {
        super(str, th);
    }

    public C1825g(Throwable th) {
        super(th);
    }
}
