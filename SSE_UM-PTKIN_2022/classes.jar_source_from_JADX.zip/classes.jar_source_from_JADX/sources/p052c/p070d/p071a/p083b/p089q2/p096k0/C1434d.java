package p052c.p070d.p071a.p083b.p089q2.p096k0;

import p052c.p070d.p139b.p140a.C2239f;

/* renamed from: c.d.a.b.q2.k0.d */
public final /* synthetic */ class C1434d implements C2239f {

    /* renamed from: c */
    public final C1449i f5182c;

    public /* synthetic */ C1434d(C1449i iVar) {
        this.f5182c = iVar;
    }

    public final Object apply(Object obj) {
        C1460o oVar = (C1460o) obj;
        this.f5182c.mo5221n(oVar);
        return oVar;
    }
}
