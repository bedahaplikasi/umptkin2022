package p052c.p070d.p071a.p083b.p126y2;

import android.net.Uri;
import java.util.List;
import java.util.Map;

/* renamed from: c.d.a.b.y2.p */
public final class C2059p {
    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static int m9759a(java.lang.String r7) {
        /*
            r1 = 4
            r3 = 3
            r2 = 1
            r4 = 0
            r0 = -1
            if (r7 != 0) goto L_0x0008
        L_0x0007:
            return r0
        L_0x0008:
            java.lang.String r5 = p052c.p070d.p071a.p083b.p126y2.C2073y.m9845t(r7)
            r5.hashCode()
            int r6 = r5.hashCode()
            switch(r6) {
                case -2123537834: goto L_0x011f;
                case -1662384011: goto L_0x0114;
                case -1662384007: goto L_0x0109;
                case -1662095187: goto L_0x00fe;
                case -1606874997: goto L_0x00f3;
                case -1487394660: goto L_0x00e8;
                case -1248337486: goto L_0x00dd;
                case -1004728940: goto L_0x00d2;
                case -387023398: goto L_0x00c6;
                case -43467528: goto L_0x00ba;
                case 13915911: goto L_0x00ae;
                case 187078296: goto L_0x00a2;
                case 187078297: goto L_0x0096;
                case 187078669: goto L_0x008b;
                case 187090232: goto L_0x0080;
                case 187091926: goto L_0x0075;
                case 187099443: goto L_0x006a;
                case 1331848029: goto L_0x005f;
                case 1503095341: goto L_0x0054;
                case 1504578661: goto L_0x0049;
                case 1504619009: goto L_0x003e;
                case 1504831518: goto L_0x0033;
                case 1505118770: goto L_0x0028;
                case 2039520277: goto L_0x001d;
                default: goto L_0x0016;
            }
        L_0x0016:
            r5 = r0
        L_0x0017:
            switch(r5) {
                case 0: goto L_0x001b;
                case 1: goto L_0x0154;
                case 2: goto L_0x0150;
                case 3: goto L_0x014d;
                case 4: goto L_0x014a;
                case 5: goto L_0x0146;
                case 6: goto L_0x0142;
                case 7: goto L_0x013e;
                case 8: goto L_0x014d;
                case 9: goto L_0x014d;
                case 10: goto L_0x013b;
                case 11: goto L_0x001b;
                case 12: goto L_0x0138;
                case 13: goto L_0x014a;
                case 14: goto L_0x0142;
                case 15: goto L_0x0134;
                case 16: goto L_0x0130;
                case 17: goto L_0x0142;
                case 18: goto L_0x014a;
                case 19: goto L_0x001b;
                case 20: goto L_0x012d;
                case 21: goto L_0x012a;
                case 22: goto L_0x014d;
                case 23: goto L_0x014d;
                default: goto L_0x001a;
            }
        L_0x001a:
            goto L_0x0007
        L_0x001b:
            r0 = r4
            goto L_0x0007
        L_0x001d:
            java.lang.String r6 = "video/x-matroska"
            boolean r5 = r5.equals(r6)
            if (r5 == 0) goto L_0x0016
            r5 = 23
            goto L_0x0017
        L_0x0028:
            java.lang.String r6 = "audio/webm"
            boolean r5 = r5.equals(r6)
            if (r5 == 0) goto L_0x0016
            r5 = 22
            goto L_0x0017
        L_0x0033:
            java.lang.String r6 = "audio/mpeg"
            boolean r5 = r5.equals(r6)
            if (r5 == 0) goto L_0x0016
            r5 = 21
            goto L_0x0017
        L_0x003e:
            java.lang.String r6 = "audio/flac"
            boolean r5 = r5.equals(r6)
            if (r5 == 0) goto L_0x0016
            r5 = 20
            goto L_0x0017
        L_0x0049:
            java.lang.String r6 = "audio/eac3"
            boolean r5 = r5.equals(r6)
            if (r5 == 0) goto L_0x0016
            r5 = 19
            goto L_0x0017
        L_0x0054:
            java.lang.String r6 = "audio/3gpp"
            boolean r5 = r5.equals(r6)
            if (r5 == 0) goto L_0x0016
            r5 = 18
            goto L_0x0017
        L_0x005f:
            java.lang.String r6 = "video/mp4"
            boolean r5 = r5.equals(r6)
            if (r5 == 0) goto L_0x0016
            r5 = 17
            goto L_0x0017
        L_0x006a:
            java.lang.String r6 = "audio/wav"
            boolean r5 = r5.equals(r6)
            if (r5 == 0) goto L_0x0016
            r5 = 16
            goto L_0x0017
        L_0x0075:
            java.lang.String r6 = "audio/ogg"
            boolean r5 = r5.equals(r6)
            if (r5 == 0) goto L_0x0016
            r5 = 15
            goto L_0x0017
        L_0x0080:
            java.lang.String r6 = "audio/mp4"
            boolean r5 = r5.equals(r6)
            if (r5 == 0) goto L_0x0016
            r5 = 14
            goto L_0x0017
        L_0x008b:
            java.lang.String r6 = "audio/amr"
            boolean r5 = r5.equals(r6)
            if (r5 == 0) goto L_0x0016
            r5 = 13
            goto L_0x0017
        L_0x0096:
            java.lang.String r6 = "audio/ac4"
            boolean r5 = r5.equals(r6)
            if (r5 == 0) goto L_0x0016
            r5 = 12
            goto L_0x0017
        L_0x00a2:
            java.lang.String r6 = "audio/ac3"
            boolean r5 = r5.equals(r6)
            if (r5 == 0) goto L_0x0016
            r5 = 11
            goto L_0x0017
        L_0x00ae:
            java.lang.String r6 = "video/x-flv"
            boolean r5 = r5.equals(r6)
            if (r5 == 0) goto L_0x0016
            r5 = 10
            goto L_0x0017
        L_0x00ba:
            java.lang.String r6 = "application/webm"
            boolean r5 = r5.equals(r6)
            if (r5 == 0) goto L_0x0016
            r5 = 9
            goto L_0x0017
        L_0x00c6:
            java.lang.String r6 = "audio/x-matroska"
            boolean r5 = r5.equals(r6)
            if (r5 == 0) goto L_0x0016
            r5 = 8
            goto L_0x0017
        L_0x00d2:
            java.lang.String r6 = "text/vtt"
            boolean r5 = r5.equals(r6)
            if (r5 == 0) goto L_0x0016
            r5 = 7
            goto L_0x0017
        L_0x00dd:
            java.lang.String r6 = "application/mp4"
            boolean r5 = r5.equals(r6)
            if (r5 == 0) goto L_0x0016
            r5 = 6
            goto L_0x0017
        L_0x00e8:
            java.lang.String r6 = "image/jpeg"
            boolean r5 = r5.equals(r6)
            if (r5 == 0) goto L_0x0016
            r5 = 5
            goto L_0x0017
        L_0x00f3:
            java.lang.String r6 = "audio/amr-wb"
            boolean r5 = r5.equals(r6)
            if (r5 == 0) goto L_0x0016
            r5 = r1
            goto L_0x0017
        L_0x00fe:
            java.lang.String r6 = "video/webm"
            boolean r5 = r5.equals(r6)
            if (r5 == 0) goto L_0x0016
            r5 = r3
            goto L_0x0017
        L_0x0109:
            java.lang.String r6 = "video/mp2t"
            boolean r5 = r5.equals(r6)
            if (r5 == 0) goto L_0x0016
            r5 = 2
            goto L_0x0017
        L_0x0114:
            java.lang.String r6 = "video/mp2p"
            boolean r5 = r5.equals(r6)
            if (r5 == 0) goto L_0x0016
            r5 = r2
            goto L_0x0017
        L_0x011f:
            java.lang.String r6 = "audio/eac3-joc"
            boolean r5 = r5.equals(r6)
            if (r5 == 0) goto L_0x0016
            r5 = r4
            goto L_0x0017
        L_0x012a:
            r0 = 7
            goto L_0x0007
        L_0x012d:
            r0 = r1
            goto L_0x0007
        L_0x0130:
            r0 = 12
            goto L_0x0007
        L_0x0134:
            r0 = 9
            goto L_0x0007
        L_0x0138:
            r0 = r2
            goto L_0x0007
        L_0x013b:
            r0 = 5
            goto L_0x0007
        L_0x013e:
            r0 = 13
            goto L_0x0007
        L_0x0142:
            r0 = 8
            goto L_0x0007
        L_0x0146:
            r0 = 14
            goto L_0x0007
        L_0x014a:
            r0 = r3
            goto L_0x0007
        L_0x014d:
            r0 = 6
            goto L_0x0007
        L_0x0150:
            r0 = 11
            goto L_0x0007
        L_0x0154:
            r0 = 10
            goto L_0x0007
        */
        throw new UnsupportedOperationException("Method not decompiled: p052c.p070d.p071a.p083b.p126y2.C2059p.m9759a(java.lang.String):int");
    }

    /* renamed from: b */
    public static int m9760b(Map<String, List<String>> map) {
        List list = map.get("Content-Type");
        return m9759a((list == null || list.isEmpty()) ? null : (String) list.get(0));
    }

    /* renamed from: c */
    public static int m9761c(Uri uri) {
        String lastPathSegment = uri.getLastPathSegment();
        if (lastPathSegment == null) {
            return -1;
        }
        if (lastPathSegment.endsWith(".ac3") || lastPathSegment.endsWith(".ec3")) {
            return 0;
        }
        if (lastPathSegment.endsWith(".ac4")) {
            return 1;
        }
        if (lastPathSegment.endsWith(".adts") || lastPathSegment.endsWith(".aac")) {
            return 2;
        }
        if (lastPathSegment.endsWith(".amr")) {
            return 3;
        }
        if (lastPathSegment.endsWith(".flac")) {
            return 4;
        }
        if (lastPathSegment.endsWith(".flv")) {
            return 5;
        }
        if (lastPathSegment.startsWith(".mk", lastPathSegment.length() - 4) || lastPathSegment.endsWith(".webm")) {
            return 6;
        }
        if (lastPathSegment.endsWith(".mp3")) {
            return 7;
        }
        if (lastPathSegment.endsWith(".mp4") || lastPathSegment.startsWith(".m4", lastPathSegment.length() - 4) || lastPathSegment.startsWith(".mp4", lastPathSegment.length() - 5) || lastPathSegment.startsWith(".cmf", lastPathSegment.length() - 5)) {
            return 8;
        }
        if (lastPathSegment.startsWith(".og", lastPathSegment.length() - 4) || lastPathSegment.endsWith(".opus")) {
            return 9;
        }
        if (lastPathSegment.endsWith(".ps") || lastPathSegment.endsWith(".mpeg") || lastPathSegment.endsWith(".mpg") || lastPathSegment.endsWith(".m2p")) {
            return 10;
        }
        if (lastPathSegment.endsWith(".ts") || lastPathSegment.startsWith(".ts", lastPathSegment.length() - 4)) {
            return 11;
        }
        if (lastPathSegment.endsWith(".wav") || lastPathSegment.endsWith(".wave")) {
            return 12;
        }
        if (lastPathSegment.endsWith(".vtt") || lastPathSegment.endsWith(".webvtt")) {
            return 13;
        }
        return (lastPathSegment.endsWith(".jpg") || lastPathSegment.endsWith(".jpeg")) ? 14 : -1;
    }
}
