package p052c.p070d.p071a.p083b.p126y2;

import p052c.p070d.p071a.p083b.p126y2.C2013a0;

/* renamed from: c.d.a.b.y2.c */
public final /* synthetic */ class C2020c implements Runnable {

    /* renamed from: c */
    public final C2013a0 f7443c;

    /* renamed from: d */
    public final C2013a0.C2015b f7444d;

    public /* synthetic */ C2020c(C2013a0 a0Var, C2013a0.C2015b bVar) {
        this.f7443c = a0Var;
        this.f7444d = bVar;
    }

    public final void run() {
        this.f7443c.mo6360h(this.f7444d);
    }
}
