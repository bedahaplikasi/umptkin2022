package p052c.p070d.p071a.p083b.p085m2;

import p052c.p070d.p071a.p083b.p085m2.C1240v;

/* renamed from: c.d.a.b.m2.d */
public final /* synthetic */ class C1198d implements Runnable {

    /* renamed from: c */
    public final C1240v.C1241a f4369c;

    /* renamed from: d */
    public final Exception f4370d;

    public /* synthetic */ C1198d(C1240v.C1241a aVar, Exception exc) {
        this.f4369c = aVar;
        this.f4370d = exc;
    }

    public final void run() {
        this.f4369c.mo4862i(this.f4370d);
    }
}
