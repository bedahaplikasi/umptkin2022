package p052c.p070d.p071a.p083b.p126y2;

import android.os.Handler;
import android.os.Message;

/* renamed from: c.d.a.b.y2.b */
public final /* synthetic */ class C2018b implements Handler.Callback {

    /* renamed from: c */
    public final C2065t f7438c;

    public /* synthetic */ C2018b(C2065t tVar) {
        this.f7438c = tVar;
    }

    public final boolean handleMessage(Message message) {
        return this.f7438c.m9790d(message);
    }
}
