package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p086n2.C1263d;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.r */
public final /* synthetic */ class C1161r implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4225a;

    /* renamed from: b */
    public final C1263d f4226b;

    public /* synthetic */ C1161r(C1138g1.C1139a aVar, C1263d dVar) {
        this.f4225a = aVar;
        this.f4226b = dVar;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        C1134f1.m5209C0(this.f4225a, this.f4226b, (C1138g1) obj);
    }
}
