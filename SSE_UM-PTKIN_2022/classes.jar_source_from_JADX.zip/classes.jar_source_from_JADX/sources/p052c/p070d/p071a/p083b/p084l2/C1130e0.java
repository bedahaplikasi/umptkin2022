package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.p126y2.C2055o;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.e0 */
public final /* synthetic */ class C1130e0 implements C2065t.C2067b {

    /* renamed from: a */
    public static final C1130e0 f4138a = new C1130e0();

    private /* synthetic */ C1130e0() {
    }

    /* renamed from: a */
    public final void mo4540a(Object obj, C2055o oVar) {
        C1134f1.m5259v0((C1138g1) obj, oVar);
    }
}
