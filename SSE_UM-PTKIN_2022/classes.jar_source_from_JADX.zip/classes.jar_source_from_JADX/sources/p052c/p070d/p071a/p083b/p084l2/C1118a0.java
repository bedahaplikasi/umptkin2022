package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.a0 */
public final /* synthetic */ class C1118a0 implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4111a;

    public /* synthetic */ C1118a0(C1138g1.C1139a aVar) {
        this.f4111a = aVar;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        ((C1138g1) obj).mo4660Y(this.f4111a);
    }
}
