package p052c.p070d.p071a.p083b.p085m2;

import p052c.p070d.p071a.p083b.p085m2.C1240v;

/* renamed from: c.d.a.b.m2.g */
public final /* synthetic */ class C1206g implements Runnable {

    /* renamed from: c */
    public final C1240v.C1241a f4393c;

    /* renamed from: d */
    public final String f4394d;

    /* renamed from: e */
    public final long f4395e;

    /* renamed from: f */
    public final long f4396f;

    public /* synthetic */ C1206g(C1240v.C1241a aVar, String str, long j, long j2) {
        this.f4393c = aVar;
        this.f4394d = str;
        this.f4395e = j;
        this.f4396f = j2;
    }

    public final void run() {
        this.f4393c.mo4864m(this.f4394d, this.f4395e, this.f4396f);
    }
}
