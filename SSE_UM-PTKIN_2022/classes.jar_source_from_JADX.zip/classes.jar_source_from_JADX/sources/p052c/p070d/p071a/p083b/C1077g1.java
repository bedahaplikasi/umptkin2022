package p052c.p070d.p071a.p083b;

/* renamed from: c.d.a.b.g1 */
public final class C1077g1 extends IllegalStateException {
    public C1077g1(C1093i2 i2Var, int i, long j) {
    }
}
