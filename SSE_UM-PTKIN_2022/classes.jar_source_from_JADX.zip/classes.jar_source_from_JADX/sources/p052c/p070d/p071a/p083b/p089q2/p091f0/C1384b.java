package p052c.p070d.p071a.p083b.p089q2.p091f0;

import p052c.p070d.p071a.p083b.p089q2.C1362b;
import p052c.p070d.p071a.p083b.p089q2.C1555s;

/* renamed from: c.d.a.b.q2.f0.b */
public final /* synthetic */ class C1384b implements C1362b.C1366d {

    /* renamed from: a */
    public final C1555s f4913a;

    public /* synthetic */ C1384b(C1555s sVar) {
        this.f4913a = sVar;
    }

    /* renamed from: a */
    public final long mo5124a(long j) {
        return this.f4913a.mo5341j(j);
    }
}
