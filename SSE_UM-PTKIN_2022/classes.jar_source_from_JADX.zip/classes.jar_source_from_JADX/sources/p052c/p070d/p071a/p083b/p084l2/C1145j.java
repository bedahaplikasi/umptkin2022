package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.j */
public final /* synthetic */ class C1145j implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4185a;

    /* renamed from: b */
    public final String f4186b;

    public /* synthetic */ C1145j(C1138g1.C1139a aVar, String str) {
        this.f4185a = aVar;
        this.f4186b = str;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        ((C1138g1) obj).mo4692p(this.f4185a, this.f4186b);
    }
}
