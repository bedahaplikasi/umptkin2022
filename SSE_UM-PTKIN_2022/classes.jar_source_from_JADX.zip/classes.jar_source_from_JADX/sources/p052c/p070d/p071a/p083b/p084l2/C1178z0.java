package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.z0 */
public final /* synthetic */ class C1178z0 implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4260a;

    /* renamed from: b */
    public final int f4261b;

    /* renamed from: c */
    public final long f4262c;

    /* renamed from: d */
    public final long f4263d;

    public /* synthetic */ C1178z0(C1138g1.C1139a aVar, int i, long j, long j2) {
        this.f4260a = aVar;
        this.f4261b = i;
        this.f4262c = j;
        this.f4263d = j2;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        ((C1138g1) obj).mo4645J(this.f4260a, this.f4261b, this.f4262c, this.f4263d);
    }
}
