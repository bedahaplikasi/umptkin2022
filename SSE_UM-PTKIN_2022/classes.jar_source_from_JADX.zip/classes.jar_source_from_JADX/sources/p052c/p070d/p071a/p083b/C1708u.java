package p052c.p070d.p071a.p083b;

import p052c.p070d.p071a.p083b.C1047b1;

/* renamed from: c.d.a.b.u */
public final /* synthetic */ class C1708u implements Runnable {

    /* renamed from: c */
    public final C1041a1 f6246c;

    /* renamed from: d */
    public final C1047b1.C1052e f6247d;

    public /* synthetic */ C1708u(C1041a1 a1Var, C1047b1.C1052e eVar) {
        this.f6246c = a1Var;
        this.f6247d = eVar;
    }

    public final void run() {
        this.f6246c.mo4251X(this.f6247d);
    }
}
