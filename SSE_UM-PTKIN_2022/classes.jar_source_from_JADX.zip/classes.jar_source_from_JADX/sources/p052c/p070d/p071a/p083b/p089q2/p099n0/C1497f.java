package p052c.p070d.p071a.p083b.p089q2.p099n0;

import p052c.p070d.p071a.p083b.p089q2.C1419j;
import p052c.p070d.p071a.p083b.p089q2.C1430k;
import p052c.p070d.p071a.p083b.p089q2.C1464l;
import p052c.p070d.p071a.p083b.p089q2.C1561x;
import p052c.p070d.p071a.p083b.p089q2.C1562y;
import p052c.p070d.p071a.p083b.p089q2.p099n0.C1507i0;
import p052c.p070d.p071a.p083b.p126y2.C2021c0;

/* renamed from: c.d.a.b.q2.n0.f */
public final class C1497f implements C1419j {

    /* renamed from: a */
    private final C1500g f5467a = new C1500g();

    /* renamed from: b */
    private final C2021c0 f5468b = new C2021c0(2786);

    /* renamed from: c */
    private boolean f5469c;

    static {
        C1486a aVar = C1486a.f5427a;
    }

    /* renamed from: b */
    static /* synthetic */ C1419j[] m7066b() {
        return new C1419j[]{new C1497f()};
    }

    /* renamed from: a */
    public void mo5141a() {
    }

    /* renamed from: c */
    public void mo5142c(C1464l lVar) {
        this.f5467a.mo5288f(lVar, new C1507i0.C1511d(0, 1));
        lVar.mo5171j();
        lVar.mo5170g(new C1562y.C1564b(-9223372036854775807L));
    }

    /* renamed from: d */
    public void mo5143d(long j, long j2) {
        this.f5469c = false;
        this.f5467a.mo5284a();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:22:?, code lost:
        return false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:7:0x0037, code lost:
        r8.mo5152h();
        r2 = r2 + 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0040, code lost:
        if ((r2 - r0) < 8192) goto L_0x0043;
     */
    /* renamed from: f */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo5144f(p052c.p070d.p071a.p083b.p089q2.C1430k r8) {
        /*
            r7 = this;
            r5 = 10
            r1 = 0
            c.d.a.b.y2.c0 r4 = new c.d.a.b.y2.c0
            r4.<init>((int) r5)
            r0 = r1
        L_0x0009:
            byte[] r2 = r4.mo6404d()
            r8.mo5157o(r2, r1, r5)
            r4.mo6399O(r1)
            int r2 = r4.mo6390F()
            r3 = 4801587(0x494433, float:6.728456E-39)
            if (r2 == r3) goto L_0x005f
            r8.mo5152h()
            r8.mo5158p(r0)
            r2 = r0
        L_0x0023:
            r3 = r1
        L_0x0024:
            byte[] r5 = r4.mo6404d()
            r6 = 6
            r8.mo5157o(r5, r1, r6)
            r4.mo6399O(r1)
            int r5 = r4.mo6393I()
            r6 = 2935(0xb77, float:4.113E-42)
            if (r5 == r6) goto L_0x0047
            r8.mo5152h()
            int r2 = r2 + 1
            int r3 = r2 - r0
            r5 = 8192(0x2000, float:1.14794E-41)
            if (r3 < r5) goto L_0x0043
        L_0x0042:
            return r1
        L_0x0043:
            r8.mo5158p(r2)
            goto L_0x0023
        L_0x0047:
            int r3 = r3 + 1
            r5 = 4
            if (r3 < r5) goto L_0x004e
            r1 = 1
            goto L_0x0042
        L_0x004e:
            byte[] r5 = r4.mo6404d()
            int r5 = p052c.p070d.p071a.p083b.p085m2.C1223n.m5760f(r5)
            r6 = -1
            if (r5 == r6) goto L_0x0042
            int r5 = r5 + -6
            r8.mo5158p(r5)
            goto L_0x0024
        L_0x005f:
            r2 = 3
            r4.mo6400P(r2)
            int r2 = r4.mo6386B()
            int r3 = r2 + 10
            int r0 = r0 + r3
            r8.mo5158p(r2)
            goto L_0x0009
        */
        throw new UnsupportedOperationException("Method not decompiled: p052c.p070d.p071a.p083b.p089q2.p099n0.C1497f.mo5144f(c.d.a.b.q2.k):boolean");
    }

    /* renamed from: i */
    public int mo5145i(C1430k kVar, C1561x xVar) {
        int b = kVar.mo5148b(this.f5468b.mo6404d(), 0, 2786);
        if (b == -1) {
            return -1;
        }
        this.f5468b.mo6399O(0);
        this.f5468b.mo6398N(b);
        if (!this.f5469c) {
            this.f5467a.mo5287e(0, 4);
            this.f5469c = true;
        }
        this.f5467a.mo5285c(this.f5468b);
        return 0;
    }
}
