package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p086n2.C1263d;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.o0 */
public final /* synthetic */ class C1156o0 implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4211a;

    /* renamed from: b */
    public final C1263d f4212b;

    public /* synthetic */ C1156o0(C1138g1.C1139a aVar, C1263d dVar) {
        this.f4211a = aVar;
        this.f4212b = dVar;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        C1134f1.m5254s1(this.f4211a, this.f4212b, (C1138g1) obj);
    }
}
