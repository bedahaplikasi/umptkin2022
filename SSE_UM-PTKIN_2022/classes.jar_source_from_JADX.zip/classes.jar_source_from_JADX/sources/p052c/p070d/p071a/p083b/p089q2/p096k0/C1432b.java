package p052c.p070d.p071a.p083b.p089q2.p096k0;

import p052c.p070d.p139b.p140a.C2239f;

/* renamed from: c.d.a.b.q2.k0.b */
public final /* synthetic */ class C1432b implements C2239f {

    /* renamed from: c */
    public static final C1432b f5180c = new C1432b();

    private /* synthetic */ C1432b() {
    }

    public final Object apply(Object obj) {
        C1460o oVar = (C1460o) obj;
        C1453k.m6879p(oVar);
        return oVar;
    }
}
