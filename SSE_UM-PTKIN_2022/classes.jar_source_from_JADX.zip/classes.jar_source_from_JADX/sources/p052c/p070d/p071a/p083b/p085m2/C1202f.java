package p052c.p070d.p071a.p083b.p085m2;

import p052c.p070d.p071a.p083b.C1067e1;
import p052c.p070d.p071a.p083b.p085m2.C1240v;
import p052c.p070d.p071a.p083b.p086n2.C1267g;

/* renamed from: c.d.a.b.m2.f */
public final /* synthetic */ class C1202f implements Runnable {

    /* renamed from: c */
    public final C1240v.C1241a f4377c;

    /* renamed from: d */
    public final C1067e1 f4378d;

    /* renamed from: e */
    public final C1267g f4379e;

    public /* synthetic */ C1202f(C1240v.C1241a aVar, C1067e1 e1Var, C1267g gVar) {
        this.f4377c = aVar;
        this.f4378d = e1Var;
        this.f4379e = gVar;
    }

    public final void run() {
        this.f4377c.mo4868u(this.f4378d, this.f4379e);
    }
}
