package p052c.p070d.p071a.p083b.p114v2;

import p052c.p070d.p071a.p083b.p086n2.C1268h;

/* renamed from: c.d.a.b.v2.d */
final class C1822d extends C1829j {

    /* renamed from: h */
    private final C1268h.C1269a<C1829j> f6675h;

    public C1822d(C1268h.C1269a<C1829j> aVar) {
        this.f6675h = aVar;
    }

    /* renamed from: n */
    public final void mo4942n() {
        this.f6675h.mo4943a(this);
    }
}
