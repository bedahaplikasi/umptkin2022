package p052c.p070d.p071a.p083b.p085m2;

import p052c.p070d.p071a.p083b.p085m2.C1240v;
import p052c.p070d.p071a.p083b.p086n2.C1263d;

/* renamed from: c.d.a.b.m2.k */
public final /* synthetic */ class C1215k implements Runnable {

    /* renamed from: c */
    public final C1240v.C1241a f4431c;

    /* renamed from: d */
    public final C1263d f4432d;

    public /* synthetic */ C1215k(C1240v.C1241a aVar, C1263d dVar) {
        this.f4431c = aVar;
        this.f4432d = dVar;
    }

    public final void run() {
        this.f4431c.mo4867s(this.f4432d);
    }
}
