package p052c.p070d.p071a.p083b.p086n2;

/* renamed from: c.d.a.b.n2.d */
public final class C1263d {

    /* renamed from: a */
    public int f4606a;

    /* renamed from: b */
    public int f4607b;

    /* renamed from: c */
    public int f4608c;

    /* renamed from: d */
    public int f4609d;

    /* renamed from: e */
    public int f4610e;

    /* renamed from: f */
    public int f4611f;

    /* renamed from: g */
    public int f4612g;

    /* renamed from: h */
    public int f4613h;

    /* renamed from: i */
    public int f4614i;

    /* renamed from: j */
    public long f4615j;

    /* renamed from: k */
    public int f4616k;

    /* renamed from: b */
    private void m5957b(long j, int i) {
        this.f4615j += j;
        this.f4616k += i;
    }

    /* renamed from: a */
    public void mo4934a(long j) {
        m5957b(j, 1);
    }

    /* renamed from: c */
    public void mo4935c() {
        synchronized (this) {
        }
    }
}
