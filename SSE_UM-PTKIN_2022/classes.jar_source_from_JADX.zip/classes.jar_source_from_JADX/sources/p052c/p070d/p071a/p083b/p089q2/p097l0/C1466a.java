package p052c.p070d.p071a.p083b.p089q2.p097l0;

import android.net.Uri;
import java.util.Map;
import p052c.p070d.p071a.p083b.p089q2.C1419j;
import p052c.p070d.p071a.p083b.p089q2.C1485n;
import p052c.p070d.p071a.p083b.p089q2.C1540o;

/* renamed from: c.d.a.b.q2.l0.a */
public final /* synthetic */ class C1466a implements C1540o {

    /* renamed from: a */
    public static final C1466a f5357a = new C1466a();

    private /* synthetic */ C1466a() {
    }

    /* renamed from: a */
    public final C1419j[] mo5109a() {
        return C1472d.m6962b();
    }

    /* renamed from: b */
    public /* synthetic */ C1419j[] mo5110b(Uri uri, Map map) {
        return C1485n.m7023a(this, uri, map);
    }
}
