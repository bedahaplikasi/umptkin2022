package p052c.p070d.p071a.p083b.p126y2;

/* renamed from: c.d.a.b.y2.l */
public interface C2046l<T> {
    /* renamed from: a */
    void mo4985a(T t);
}
