package p052c.p070d.p071a.p083b.p124w2;

import java.util.List;
import p052c.p070d.p071a.p083b.p111u2.C1773s0;
import p052c.p070d.p071a.p083b.p111u2.p113w0.C1804n;
import p052c.p070d.p071a.p083b.p111u2.p113w0.C1805o;

/* renamed from: c.d.a.b.w2.i */
public final class C1927i extends C1912e {

    /* renamed from: g */
    private final int f7196g;

    /* renamed from: h */
    private final Object f7197h;

    public C1927i(C1773s0 s0Var, int i, int i2) {
        this(s0Var, i, i2, 0, (Object) null);
    }

    public C1927i(C1773s0 s0Var, int i, int i2, int i3, Object obj) {
        super(s0Var, new int[]{i}, i2);
        this.f7196g = i3;
        this.f7197h = obj;
    }

    /* renamed from: j */
    public void mo6188j(long j, long j2, long j3, List<? extends C1804n> list, C1805o[] oVarArr) {
    }

    /* renamed from: n */
    public int mo6189n() {
        return this.f7196g;
    }

    /* renamed from: o */
    public int mo6190o() {
        return 0;
    }

    /* renamed from: q */
    public Object mo6192q() {
        return this.f7197h;
    }
}
