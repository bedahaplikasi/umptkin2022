package p052c.p070d.p071a.p083b;

import p052c.p070d.p071a.p083b.C1903w1;
import p052c.p070d.p071a.p083b.p111u2.C1758n0;
import p052c.p070d.p071a.p083b.p126y2.C2071w;

/* renamed from: c.d.a.b.a2 */
public interface C1043a2 extends C1903w1.C1905b {

    /* renamed from: c.d.a.b.a2$a */
    public interface C1044a {
        /* renamed from: a */
        void mo4299a();

        /* renamed from: b */
        void mo4300b(long j);
    }

    /* renamed from: A */
    void mo4276A(float f, float f2);

    /* renamed from: a */
    String mo4277a();

    /* renamed from: c */
    void mo4278c();

    /* renamed from: d */
    boolean mo4279d();

    /* renamed from: e */
    void mo4280e();

    /* renamed from: f */
    int mo4281f();

    /* renamed from: g */
    boolean mo4282g();

    /* renamed from: j */
    int mo4283j();

    /* renamed from: k */
    void mo4284k(int i);

    /* renamed from: l */
    boolean mo4285l();

    /* renamed from: m */
    void mo4286m(C1064d2 d2Var, C1067e1[] e1VarArr, C1758n0 n0Var, long j, boolean z, boolean z2, long j2, long j3);

    /* renamed from: o */
    void mo4287o(long j, long j2);

    /* renamed from: q */
    C1758n0 mo4288q();

    /* renamed from: r */
    void mo4289r(C1067e1[] e1VarArr, C1758n0 n0Var, long j, long j2);

    /* renamed from: s */
    void mo4290s();

    void start();

    void stop();

    /* renamed from: t */
    void mo4293t();

    /* renamed from: u */
    long mo4294u();

    /* renamed from: v */
    void mo4295v(long j);

    /* renamed from: w */
    boolean mo4296w();

    /* renamed from: x */
    C2071w mo4297x();

    /* renamed from: y */
    C1060c2 mo4298y();
}
