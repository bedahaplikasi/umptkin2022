package p052c.p070d.p071a.p083b.p089q2;

import p052c.p070d.p071a.p083b.p089q2.C1362b;

/* renamed from: c.d.a.b.q2.c */
public final /* synthetic */ class C1371c {
    /* renamed from: a */
    public static void m6409a(C1362b.C1368f fVar) {
    }
}
