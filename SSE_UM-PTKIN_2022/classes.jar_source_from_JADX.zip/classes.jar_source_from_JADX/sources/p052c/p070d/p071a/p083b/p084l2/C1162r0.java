package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.C1067e1;
import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p086n2.C1267g;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.r0 */
public final /* synthetic */ class C1162r0 implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4227a;

    /* renamed from: b */
    public final C1067e1 f4228b;

    /* renamed from: c */
    public final C1267g f4229c;

    public /* synthetic */ C1162r0(C1138g1.C1139a aVar, C1067e1 e1Var, C1267g gVar) {
        this.f4227a = aVar;
        this.f4228b = e1Var;
        this.f4229c = gVar;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        C1134f1.m5260v1(this.f4227a, this.f4228b, this.f4229c, (C1138g1) obj);
    }
}
