package p052c.p070d.p071a.p083b.p114v2;

import p052c.p070d.p071a.p083b.p086n2.C1265f;

/* renamed from: c.d.a.b.v2.i */
public class C1828i extends C1265f {

    /* renamed from: k */
    public long f6677k;

    public C1828i() {
        super(1);
    }
}
