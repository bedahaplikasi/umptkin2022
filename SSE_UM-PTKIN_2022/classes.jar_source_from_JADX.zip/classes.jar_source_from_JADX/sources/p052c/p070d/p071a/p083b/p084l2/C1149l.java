package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.l */
public final /* synthetic */ class C1149l implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4196a;

    /* renamed from: b */
    public final int f4197b;

    /* renamed from: c */
    public final int f4198c;

    public /* synthetic */ C1149l(C1138g1.C1139a aVar, int i, int i2) {
        this.f4196a = aVar;
        this.f4197b = i;
        this.f4198c = i2;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        ((C1138g1) obj).mo4664b(this.f4196a, this.f4197b, this.f4198c);
    }
}
