package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p126y2.C2065t;
import p052c.p070d.p071a.p083b.p127z2.C2123z;

/* renamed from: c.d.a.b.l2.e1 */
public final /* synthetic */ class C1131e1 implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4139a;

    /* renamed from: b */
    public final C2123z f4140b;

    public /* synthetic */ C1131e1(C1138g1.C1139a aVar, C2123z zVar) {
        this.f4139a = aVar;
        this.f4140b = zVar;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        C1134f1.m5262w1(this.f4139a, this.f4140b, (C1138g1) obj);
    }
}
