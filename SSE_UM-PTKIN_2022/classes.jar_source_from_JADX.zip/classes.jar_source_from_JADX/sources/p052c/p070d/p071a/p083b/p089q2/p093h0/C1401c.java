package p052c.p070d.p071a.p083b.p089q2.p093h0;

import p052c.p070d.p071a.p083b.p089q2.C1430k;
import p052c.p070d.p071a.p083b.p089q2.C1557t;
import p052c.p070d.p071a.p083b.p126y2.C2030g;

/* renamed from: c.d.a.b.q2.h0.c */
final class C1401c extends C1557t {

    /* renamed from: b */
    private final long f4997b;

    public C1401c(C1430k kVar, long j) {
        super(kVar);
        C2030g.m9536a(kVar.mo5159q() >= j);
        this.f4997b = j;
    }

    /* renamed from: a */
    public long mo5147a() {
        return super.mo5147a() - this.f4997b;
    }

    /* renamed from: n */
    public long mo5156n() {
        return super.mo5156n() - this.f4997b;
    }

    /* renamed from: q */
    public long mo5159q() {
        return super.mo5159q() - this.f4997b;
    }
}
