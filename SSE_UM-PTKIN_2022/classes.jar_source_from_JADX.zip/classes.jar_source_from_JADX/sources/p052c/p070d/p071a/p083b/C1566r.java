package p052c.p070d.p071a.p083b;

import p052c.p070d.p071a.p083b.C1696t1;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.r */
public final /* synthetic */ class C1566r implements C2065t.C2066a {

    /* renamed from: a */
    public final C1568r1 f5864a;

    /* renamed from: b */
    public final int f5865b;

    public /* synthetic */ C1566r(C1568r1 r1Var, int i) {
        this.f5864a = r1Var;
        this.f5865b = i;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        C1041a1.m4595r0(this.f5864a, this.f5865b, (C1696t1.C1700c) obj);
    }
}
