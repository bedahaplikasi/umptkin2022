package p052c.p070d.p071a.p083b.p085m2;

@Deprecated
/* renamed from: c.d.a.b.m2.s */
public interface C1235s {
    /* renamed from: M */
    void mo4608M(float f);

    /* renamed from: a */
    void mo4433a(boolean z);

    /* renamed from: l */
    void mo4618l(C1230p pVar);
}
