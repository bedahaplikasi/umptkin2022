package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.C1696t1;
import p052c.p070d.p071a.p083b.p126y2.C2055o;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.f */
public final /* synthetic */ class C1132f implements C2065t.C2067b {

    /* renamed from: a */
    public final C1134f1 f4141a;

    /* renamed from: b */
    public final C1696t1 f4142b;

    public /* synthetic */ C1132f(C1134f1 f1Var, C1696t1 t1Var) {
        this.f4141a = f1Var;
        this.f4142b = t1Var;
    }

    /* renamed from: a */
    public final void mo4540a(Object obj, C2055o oVar) {
        this.f4141a.mo4600A1(this.f4142b, (C1138g1) obj, oVar);
    }
}
