package p052c.p070d.p071a.p083b.p089q2.p095j0;

import p052c.p070d.p071a.p083b.p102s2.p107m.C1652h;

/* renamed from: c.d.a.b.q2.j0.b */
public final /* synthetic */ class C1421b implements C1652h.C1653a {

    /* renamed from: a */
    public static final C1421b f5140a = new C1421b();

    private /* synthetic */ C1421b() {
    }

    /* renamed from: a */
    public final boolean mo5204a(int i, int i2, int i3, int i4, int i5) {
        return C1425f.m6704o(i, i2, i3, i4, i5);
    }
}
