package p052c.p070d.p071a.p083b.p089q2.p099n0;

import p052c.p070d.p071a.p083b.p089q2.C1464l;
import p052c.p070d.p071a.p083b.p089q2.p099n0.C1507i0;
import p052c.p070d.p071a.p083b.p126y2.C2021c0;
import p052c.p070d.p071a.p083b.p126y2.C2047l0;

/* renamed from: c.d.a.b.q2.n0.c0 */
public interface C1492c0 {
    /* renamed from: b */
    void mo5277b(C2047l0 l0Var, C1464l lVar, C1507i0.C1511d dVar);

    /* renamed from: c */
    void mo5278c(C2021c0 c0Var);
}
