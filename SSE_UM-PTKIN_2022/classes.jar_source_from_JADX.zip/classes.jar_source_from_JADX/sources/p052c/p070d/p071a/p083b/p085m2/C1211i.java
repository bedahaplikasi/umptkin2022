package p052c.p070d.p071a.p083b.p085m2;

import p052c.p070d.p071a.p083b.p085m2.C1240v;

/* renamed from: c.d.a.b.m2.i */
public final /* synthetic */ class C1211i implements Runnable {

    /* renamed from: c */
    public final C1240v.C1241a f4413c;

    /* renamed from: d */
    public final long f4414d;

    public /* synthetic */ C1211i(C1240v.C1241a aVar, long j) {
        this.f4413c = aVar;
        this.f4414d = j;
    }

    public final void run() {
        this.f4413c.mo4869w(this.f4414d);
    }
}
