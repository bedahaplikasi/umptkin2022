package p052c.p070d.p071a.p083b.p089q2;

/* renamed from: c.d.a.b.q2.l */
public interface C1464l {

    /* renamed from: b */
    public static final C1464l f5356b = new C1465a();

    /* renamed from: c.d.a.b.q2.l$a */
    class C1465a implements C1464l {
        C1465a() {
        }

        /* renamed from: e */
        public C1369b0 mo5169e(int i, int i2) {
            throw new UnsupportedOperationException();
        }

        /* renamed from: g */
        public void mo5170g(C1562y yVar) {
            throw new UnsupportedOperationException();
        }

        /* renamed from: j */
        public void mo5171j() {
            throw new UnsupportedOperationException();
        }
    }

    /* renamed from: e */
    C1369b0 mo5169e(int i, int i2);

    /* renamed from: g */
    void mo5170g(C1562y yVar);

    /* renamed from: j */
    void mo5171j();
}
