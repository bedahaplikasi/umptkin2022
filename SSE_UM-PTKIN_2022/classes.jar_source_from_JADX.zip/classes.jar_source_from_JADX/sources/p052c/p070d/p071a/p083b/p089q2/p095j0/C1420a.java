package p052c.p070d.p071a.p083b.p089q2.p095j0;

import android.net.Uri;
import java.util.Map;
import p052c.p070d.p071a.p083b.p089q2.C1419j;
import p052c.p070d.p071a.p083b.p089q2.C1485n;
import p052c.p070d.p071a.p083b.p089q2.C1540o;

/* renamed from: c.d.a.b.q2.j0.a */
public final /* synthetic */ class C1420a implements C1540o {

    /* renamed from: a */
    public static final C1420a f5139a = new C1420a();

    private /* synthetic */ C1420a() {
    }

    /* renamed from: a */
    public final C1419j[] mo5109a() {
        return C1425f.m6703n();
    }

    /* renamed from: b */
    public /* synthetic */ C1419j[] mo5110b(Uri uri, Map map) {
        return C1485n.m7023a(this, uri, map);
    }
}
