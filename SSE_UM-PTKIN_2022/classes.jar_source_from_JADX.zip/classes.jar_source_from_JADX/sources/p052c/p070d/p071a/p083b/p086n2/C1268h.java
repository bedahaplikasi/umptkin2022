package p052c.p070d.p071a.p083b.p086n2;

/* renamed from: c.d.a.b.n2.h */
public abstract class C1268h extends C1258a {

    /* renamed from: d */
    public long f4629d;

    /* renamed from: e */
    public int f4630e;

    /* renamed from: c.d.a.b.n2.h$a */
    public interface C1269a<S extends C1268h> {
        /* renamed from: a */
        void mo4943a(S s);
    }

    /* renamed from: n */
    public abstract void mo4942n();
}
