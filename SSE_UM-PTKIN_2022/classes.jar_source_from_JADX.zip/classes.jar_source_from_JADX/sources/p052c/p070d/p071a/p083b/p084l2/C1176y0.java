package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.y0 */
public final /* synthetic */ class C1176y0 implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4256a;

    /* renamed from: b */
    public final Exception f4257b;

    public /* synthetic */ C1176y0(C1138g1.C1139a aVar, Exception exc) {
        this.f4256a = aVar;
        this.f4257b = exc;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        ((C1138g1) obj).mo4670e(this.f4256a, this.f4257b);
    }
}
