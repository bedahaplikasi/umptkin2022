package p052c.p070d.p071a.p083b.p089q2.p095j0;

import p052c.p070d.p071a.p083b.p089q2.C1562y;

/* renamed from: c.d.a.b.q2.j0.g */
interface C1426g extends C1562y {

    /* renamed from: c.d.a.b.q2.j0.g$a */
    public static class C1427a extends C1562y.C1564b implements C1426g {
        public C1427a() {
            super(-9223372036854775807L);
        }

        /* renamed from: b */
        public long mo5205b(long j) {
            return 0;
        }

        /* renamed from: e */
        public long mo5206e() {
            return -1;
        }
    }

    /* renamed from: b */
    long mo5205b(long j);

    /* renamed from: e */
    long mo5206e();
}
