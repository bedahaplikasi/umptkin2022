package p052c.p070d.p071a.p083b.p089q2.p092g0;

import p052c.p070d.p071a.p083b.C1359q1;
import p052c.p070d.p071a.p083b.p089q2.C1369b0;
import p052c.p070d.p071a.p083b.p126y2.C2021c0;

/* renamed from: c.d.a.b.q2.g0.e */
abstract class C1394e {

    /* renamed from: a */
    protected final C1369b0 f4962a;

    /* renamed from: c.d.a.b.q2.g0.e$a */
    public static final class C1395a extends C1359q1 {
        public C1395a(String str) {
            super(str);
        }
    }

    protected C1394e(C1369b0 b0Var) {
        this.f4962a = b0Var;
    }

    /* renamed from: a */
    public final boolean mo5167a(C2021c0 c0Var, long j) {
        return mo5162b(c0Var) && mo5163c(c0Var, j);
    }

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public abstract boolean mo5162b(C2021c0 c0Var);

    /* access modifiers changed from: protected */
    /* renamed from: c */
    public abstract boolean mo5163c(C2021c0 c0Var, long j);
}
