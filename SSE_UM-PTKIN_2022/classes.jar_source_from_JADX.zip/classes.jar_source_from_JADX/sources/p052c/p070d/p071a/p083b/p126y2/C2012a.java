package p052c.p070d.p071a.p083b.p126y2;

import java.util.concurrent.CopyOnWriteArraySet;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.y2.a */
public final /* synthetic */ class C2012a implements Runnable {

    /* renamed from: c */
    public final CopyOnWriteArraySet f7428c;

    /* renamed from: d */
    public final int f7429d;

    /* renamed from: e */
    public final C2065t.C2066a f7430e;

    public /* synthetic */ C2012a(CopyOnWriteArraySet copyOnWriteArraySet, int i, C2065t.C2066a aVar) {
        this.f7428c = copyOnWriteArraySet;
        this.f7429d = i;
        this.f7430e = aVar;
    }

    public final void run() {
        C2065t.m9792f(this.f7428c, this.f7429d, this.f7430e);
    }
}
