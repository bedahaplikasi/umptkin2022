package p052c.p070d.p071a.p083b.p126y2;

/* renamed from: c.d.a.b.y2.r */
public interface C2062r {

    /* renamed from: c.d.a.b.y2.r$a */
    public interface C2063a {
        /* renamed from: a */
        void mo6464a();
    }

    /* renamed from: a */
    boolean mo6453a(C2063a aVar);

    /* renamed from: b */
    boolean mo6454b(int i);

    /* renamed from: c */
    C2063a mo6455c(int i, int i2, int i3);

    /* renamed from: d */
    boolean mo6456d(int i);

    /* renamed from: e */
    C2063a mo6457e(int i, int i2, int i3, Object obj);

    /* renamed from: f */
    boolean mo6458f(int i, long j);

    /* renamed from: g */
    void mo6459g(int i);

    /* renamed from: h */
    C2063a mo6460h(int i, Object obj);

    /* renamed from: i */
    void mo6461i(Object obj);

    /* renamed from: j */
    boolean mo6462j(Runnable runnable);

    /* renamed from: k */
    C2063a mo6463k(int i);
}
