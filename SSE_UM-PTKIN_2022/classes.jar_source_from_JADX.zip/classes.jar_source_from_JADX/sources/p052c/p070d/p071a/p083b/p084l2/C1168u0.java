package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.C1099j1;
import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.u0 */
public final /* synthetic */ class C1168u0 implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4238a;

    /* renamed from: b */
    public final C1099j1 f4239b;

    /* renamed from: c */
    public final int f4240c;

    public /* synthetic */ C1168u0(C1138g1.C1139a aVar, C1099j1 j1Var, int i) {
        this.f4238a = aVar;
        this.f4239b = j1Var;
        this.f4240c = i;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        ((C1138g1) obj).mo4643H(this.f4238a, this.f4239b, this.f4240c);
    }
}
