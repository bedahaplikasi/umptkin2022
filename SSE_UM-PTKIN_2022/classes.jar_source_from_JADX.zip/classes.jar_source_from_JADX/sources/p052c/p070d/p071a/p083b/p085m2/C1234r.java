package p052c.p070d.p071a.p083b.p085m2;

/* renamed from: c.d.a.b.m2.r */
public final /* synthetic */ class C1234r {
    /* renamed from: a */
    public static void m5779a(C1235s sVar, C1230p pVar) {
    }

    /* renamed from: b */
    public static void m5780b(C1235s sVar, boolean z) {
    }

    /* renamed from: c */
    public static void m5781c(C1235s sVar, float f) {
    }
}
