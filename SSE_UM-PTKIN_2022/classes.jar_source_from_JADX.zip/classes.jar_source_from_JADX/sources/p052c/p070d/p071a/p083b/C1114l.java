package p052c.p070d.p071a.p083b;

import p052c.p070d.p071a.p083b.C1696t1;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l */
public final /* synthetic */ class C1114l implements C2065t.C2066a {

    /* renamed from: a */
    public final C1568r1 f4091a;

    public /* synthetic */ C1114l(C1568r1 r1Var) {
        this.f4091a = r1Var;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        C1041a1.m4588k0(this.f4091a, (C1696t1.C1700c) obj);
    }
}
