package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.g0 */
public final /* synthetic */ class C1137g0 implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4161a;

    /* renamed from: b */
    public final boolean f4162b;

    public /* synthetic */ C1137g0(C1138g1.C1139a aVar, boolean z) {
        this.f4161a = aVar;
        this.f4162b = z;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        ((C1138g1) obj).mo4684l(this.f4161a, this.f4162b);
    }
}
