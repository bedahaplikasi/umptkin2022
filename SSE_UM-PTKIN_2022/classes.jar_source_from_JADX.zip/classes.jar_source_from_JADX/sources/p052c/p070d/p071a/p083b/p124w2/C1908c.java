package p052c.p070d.p071a.p083b.p124w2;

import java.util.Comparator;

/* renamed from: c.d.a.b.w2.c */
public final /* synthetic */ class C1908c implements Comparator {

    /* renamed from: c */
    public static final C1908c f7066c = new C1908c();

    private /* synthetic */ C1908c() {
    }

    public final int compare(Object obj, Object obj2) {
        return C1913f.m9138u((Integer) obj, (Integer) obj2);
    }
}
