package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.i */
public final /* synthetic */ class C1143i implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4179a;

    /* renamed from: b */
    public final boolean f4180b;

    /* renamed from: c */
    public final int f4181c;

    public /* synthetic */ C1143i(C1138g1.C1139a aVar, boolean z, int i) {
        this.f4179a = aVar;
        this.f4180b = z;
        this.f4181c = i;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        ((C1138g1) obj).mo4665b0(this.f4179a, this.f4180b, this.f4181c);
    }
}
