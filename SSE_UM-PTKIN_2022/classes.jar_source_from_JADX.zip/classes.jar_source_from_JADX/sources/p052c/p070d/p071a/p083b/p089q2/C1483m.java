package p052c.p070d.p071a.p083b.p089q2;

/* renamed from: c.d.a.b.q2.m */
final class C1483m {
    /* renamed from: a */
    public static int m7014a(C1430k kVar, byte[] bArr, int i, int i2) {
        int i3 = 0;
        while (i3 < i2) {
            int f = kVar.mo5151f(bArr, i + i3, i2 - i3);
            if (f == -1) {
                break;
            }
            i3 += f;
        }
        return i3;
    }
}
