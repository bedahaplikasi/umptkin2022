package p052c.p070d.p071a.p083b.p124w2;

import java.util.Comparator;
import p052c.p070d.p071a.p083b.C1067e1;

/* renamed from: c.d.a.b.w2.a */
public final /* synthetic */ class C1906a implements Comparator {

    /* renamed from: c */
    public static final C1906a f7064c = new C1906a();

    private /* synthetic */ C1906a() {
    }

    public final int compare(Object obj, Object obj2) {
        return C1912e.m9107v((C1067e1) obj, (C1067e1) obj2);
    }
}
