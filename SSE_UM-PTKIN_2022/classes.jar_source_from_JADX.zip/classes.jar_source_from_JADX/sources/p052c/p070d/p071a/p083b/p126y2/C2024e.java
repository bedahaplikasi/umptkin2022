package p052c.p070d.p071a.p083b.p126y2;

import java.util.Comparator;
import p052c.p070d.p071a.p083b.p126y2.C2027f0;

/* renamed from: c.d.a.b.y2.e */
public final /* synthetic */ class C2024e implements Comparator {

    /* renamed from: c */
    public static final C2024e f7453c = new C2024e();

    private /* synthetic */ C2024e() {
    }

    public final int compare(Object obj, Object obj2) {
        return Float.compare(((C2027f0.C2029b) obj).f7469c, ((C2027f0.C2029b) obj2).f7469c);
    }
}
