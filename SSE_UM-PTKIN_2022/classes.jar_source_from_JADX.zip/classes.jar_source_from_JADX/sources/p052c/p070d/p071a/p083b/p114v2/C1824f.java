package p052c.p070d.p071a.p083b.p114v2;

import p052c.p070d.p071a.p083b.p086n2.C1262c;

/* renamed from: c.d.a.b.v2.f */
public interface C1824f extends C1262c<C1828i, C1829j, C1825g> {
    /* renamed from: b */
    void mo6028b(long j);
}
