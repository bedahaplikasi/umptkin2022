package p052c.p070d.p071a.p083b.p086n2;

import p052c.p070d.p071a.p083b.p086n2.C1264e;

/* renamed from: c.d.a.b.n2.c */
public interface C1262c<I, O, E extends C1264e> {
    /* renamed from: a */
    void mo4929a();

    /* renamed from: c */
    void mo4930c(I i);

    /* renamed from: d */
    O mo4931d();

    /* renamed from: e */
    I mo4932e();

    void flush();
}
