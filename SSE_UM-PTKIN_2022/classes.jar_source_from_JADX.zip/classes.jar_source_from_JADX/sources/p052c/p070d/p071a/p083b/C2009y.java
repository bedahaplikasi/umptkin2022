package p052c.p070d.p071a.p083b;

import p052c.p070d.p139b.p140a.C2253m;

/* renamed from: c.d.a.b.y */
public final /* synthetic */ class C2009y implements C2253m {

    /* renamed from: c */
    public final C1047b1 f7427c;

    public /* synthetic */ C2009y(C1047b1 b1Var) {
        this.f7427c = b1Var;
    }

    public final Object get() {
        return this.f7427c.mo4304O();
    }
}
