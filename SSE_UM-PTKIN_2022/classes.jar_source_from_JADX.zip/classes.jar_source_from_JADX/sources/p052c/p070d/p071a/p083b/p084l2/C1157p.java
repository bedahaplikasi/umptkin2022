package p052c.p070d.p071a.p083b.p084l2;

import java.io.IOException;
import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p111u2.C1716b0;
import p052c.p070d.p071a.p083b.p111u2.C1810y;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.p */
public final /* synthetic */ class C1157p implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4213a;

    /* renamed from: b */
    public final C1810y f4214b;

    /* renamed from: c */
    public final C1716b0 f4215c;

    /* renamed from: d */
    public final IOException f4216d;

    /* renamed from: e */
    public final boolean f4217e;

    public /* synthetic */ C1157p(C1138g1.C1139a aVar, C1810y yVar, C1716b0 b0Var, IOException iOException, boolean z) {
        this.f4213a = aVar;
        this.f4214b = yVar;
        this.f4215c = b0Var;
        this.f4216d = iOException;
        this.f4217e = z;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        ((C1138g1) obj).mo4649N(this.f4213a, this.f4214b, this.f4215c, this.f4216d, this.f4217e);
    }
}
