package p052c.p070d.p071a.p083b.p089q2;

import p052c.p070d.p071a.p083b.p125x2.C1979k;

/* renamed from: c.d.a.b.q2.k */
public interface C1430k extends C1979k {
    /* renamed from: a */
    long mo5147a();

    /* renamed from: b */
    int mo5148b(byte[] bArr, int i, int i2);

    /* renamed from: c */
    int mo5149c(int i);

    /* renamed from: d */
    boolean mo5150d(byte[] bArr, int i, int i2, boolean z);

    /* renamed from: f */
    int mo5151f(byte[] bArr, int i, int i2);

    /* renamed from: h */
    void mo5152h();

    /* renamed from: i */
    void mo5153i(int i);

    /* renamed from: j */
    boolean mo5154j(int i, boolean z);

    /* renamed from: m */
    boolean mo5155m(byte[] bArr, int i, int i2, boolean z);

    /* renamed from: n */
    long mo5156n();

    /* renamed from: o */
    void mo5157o(byte[] bArr, int i, int i2);

    /* renamed from: p */
    void mo5158p(int i);

    /* renamed from: q */
    long mo5159q();

    void readFully(byte[] bArr, int i, int i2);
}
