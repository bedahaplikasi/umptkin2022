package p052c.p070d.p071a.p083b;

import p052c.p070d.p071a.p083b.C1047b1;

/* renamed from: c.d.a.b.p */
public final /* synthetic */ class C1281p implements C1047b1.C1053f {

    /* renamed from: a */
    public final C1041a1 f4661a;

    public /* synthetic */ C1281p(C1041a1 a1Var) {
        this.f4661a = a1Var;
    }

    /* renamed from: a */
    public final void mo4329a(C1047b1.C1052e eVar) {
        this.f4661a.mo4252Z(eVar);
    }
}
