package p052c.p070d.p071a.p083b.p114v2.p117o;

import java.util.List;
import p052c.p070d.p071a.p083b.p114v2.C1818b;
import p052c.p070d.p071a.p083b.p114v2.C1823e;

/* renamed from: c.d.a.b.v2.o.b */
final class C1859b implements C1823e {

    /* renamed from: c */
    private final List<C1818b> f6858c;

    public C1859b(List<C1818b> list) {
        this.f6858c = list;
    }

    /* renamed from: a */
    public int mo6033a(long j) {
        return -1;
    }

    /* renamed from: b */
    public long mo6034b(int i) {
        return 0;
    }

    /* renamed from: c */
    public List<C1818b> mo6035c(long j) {
        return this.f6858c;
    }

    /* renamed from: d */
    public int mo6036d() {
        return 1;
    }
}
