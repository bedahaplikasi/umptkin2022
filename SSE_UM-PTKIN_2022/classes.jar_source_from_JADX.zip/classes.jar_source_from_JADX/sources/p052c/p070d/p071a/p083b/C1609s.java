package p052c.p070d.p071a.p083b;

import p052c.p070d.p071a.p083b.C1696t1;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.s */
public final /* synthetic */ class C1609s implements C2065t.C2066a {

    /* renamed from: a */
    public static final C1609s f6049a = new C1609s();

    private /* synthetic */ C1609s() {
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        ((C1696t1.C1700c) obj).mo4468v(C1939x0.m9225b(new C1063d1(1)));
    }
}
