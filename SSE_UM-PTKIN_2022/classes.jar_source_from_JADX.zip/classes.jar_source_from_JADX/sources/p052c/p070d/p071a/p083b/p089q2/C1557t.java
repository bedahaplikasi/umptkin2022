package p052c.p070d.p071a.p083b.p089q2;

/* renamed from: c.d.a.b.q2.t */
public class C1557t implements C1430k {

    /* renamed from: a */
    private final C1430k f5847a;

    public C1557t(C1430k kVar) {
        this.f5847a = kVar;
    }

    /* renamed from: a */
    public long mo5147a() {
        return this.f5847a.mo5147a();
    }

    /* renamed from: b */
    public int mo5148b(byte[] bArr, int i, int i2) {
        return this.f5847a.mo5148b(bArr, i, i2);
    }

    /* renamed from: c */
    public int mo5149c(int i) {
        return this.f5847a.mo5149c(i);
    }

    /* renamed from: d */
    public boolean mo5150d(byte[] bArr, int i, int i2, boolean z) {
        return this.f5847a.mo5150d(bArr, i, i2, z);
    }

    /* renamed from: f */
    public int mo5151f(byte[] bArr, int i, int i2) {
        return this.f5847a.mo5151f(bArr, i, i2);
    }

    /* renamed from: h */
    public void mo5152h() {
        this.f5847a.mo5152h();
    }

    /* renamed from: i */
    public void mo5153i(int i) {
        this.f5847a.mo5153i(i);
    }

    /* renamed from: j */
    public boolean mo5154j(int i, boolean z) {
        return this.f5847a.mo5154j(i, z);
    }

    /* renamed from: m */
    public boolean mo5155m(byte[] bArr, int i, int i2, boolean z) {
        return this.f5847a.mo5155m(bArr, i, i2, z);
    }

    /* renamed from: n */
    public long mo5156n() {
        return this.f5847a.mo5156n();
    }

    /* renamed from: o */
    public void mo5157o(byte[] bArr, int i, int i2) {
        this.f5847a.mo5157o(bArr, i, i2);
    }

    /* renamed from: p */
    public void mo5158p(int i) {
        this.f5847a.mo5158p(i);
    }

    /* renamed from: q */
    public long mo5159q() {
        return this.f5847a.mo5159q();
    }

    public void readFully(byte[] bArr, int i, int i2) {
        this.f5847a.readFully(bArr, i, i2);
    }
}
