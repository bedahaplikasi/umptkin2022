package p052c.p070d.p071a.p083b.p085m2;

import p052c.p070d.p071a.p083b.C1567r0;

/* renamed from: c.d.a.b.m2.a */
public final /* synthetic */ class C1182a implements C1567r0 {

    /* renamed from: a */
    public static final C1182a f4276a = new C1182a();

    private /* synthetic */ C1182a() {
    }
}
