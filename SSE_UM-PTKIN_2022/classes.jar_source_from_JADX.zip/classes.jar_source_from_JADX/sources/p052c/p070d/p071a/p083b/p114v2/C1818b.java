package p052c.p070d.p071a.p083b.p114v2;

import android.graphics.Bitmap;
import android.text.Layout;
import android.text.Spanned;
import android.text.SpannedString;
import p052c.p070d.p071a.p083b.p126y2.C2030g;

/* renamed from: c.d.a.b.v2.b */
public final class C1818b {

    /* renamed from: r */
    public static final C1818b f6640r;

    /* renamed from: a */
    public final CharSequence f6641a;

    /* renamed from: b */
    public final Layout.Alignment f6642b;

    /* renamed from: c */
    public final Layout.Alignment f6643c;

    /* renamed from: d */
    public final Bitmap f6644d;

    /* renamed from: e */
    public final float f6645e;

    /* renamed from: f */
    public final int f6646f;

    /* renamed from: g */
    public final int f6647g;

    /* renamed from: h */
    public final float f6648h;

    /* renamed from: i */
    public final int f6649i;

    /* renamed from: j */
    public final float f6650j;

    /* renamed from: k */
    public final float f6651k;

    /* renamed from: l */
    public final boolean f6652l;

    /* renamed from: m */
    public final int f6653m;

    /* renamed from: n */
    public final int f6654n;

    /* renamed from: o */
    public final float f6655o;

    /* renamed from: p */
    public final int f6656p;

    /* renamed from: q */
    public final float f6657q;

    /* renamed from: c.d.a.b.v2.b$b */
    public static final class C1820b {

        /* renamed from: a */
        private CharSequence f6658a;

        /* renamed from: b */
        private Bitmap f6659b;

        /* renamed from: c */
        private Layout.Alignment f6660c;

        /* renamed from: d */
        private Layout.Alignment f6661d;

        /* renamed from: e */
        private float f6662e;

        /* renamed from: f */
        private int f6663f;

        /* renamed from: g */
        private int f6664g;

        /* renamed from: h */
        private float f6665h;

        /* renamed from: i */
        private int f6666i;

        /* renamed from: j */
        private int f6667j;

        /* renamed from: k */
        private float f6668k;

        /* renamed from: l */
        private float f6669l;

        /* renamed from: m */
        private float f6670m;

        /* renamed from: n */
        private boolean f6671n;

        /* renamed from: o */
        private int f6672o;

        /* renamed from: p */
        private int f6673p;

        /* renamed from: q */
        private float f6674q;

        public C1820b() {
            this.f6658a = null;
            this.f6659b = null;
            this.f6660c = null;
            this.f6661d = null;
            this.f6662e = -3.4028235E38f;
            this.f6663f = Integer.MIN_VALUE;
            this.f6664g = Integer.MIN_VALUE;
            this.f6665h = -3.4028235E38f;
            this.f6666i = Integer.MIN_VALUE;
            this.f6667j = Integer.MIN_VALUE;
            this.f6668k = -3.4028235E38f;
            this.f6669l = -3.4028235E38f;
            this.f6670m = -3.4028235E38f;
            this.f6671n = false;
            this.f6672o = -16777216;
            this.f6673p = Integer.MIN_VALUE;
        }

        private C1820b(C1818b bVar) {
            this.f6658a = bVar.f6641a;
            this.f6659b = bVar.f6644d;
            this.f6660c = bVar.f6642b;
            this.f6661d = bVar.f6643c;
            this.f6662e = bVar.f6645e;
            this.f6663f = bVar.f6646f;
            this.f6664g = bVar.f6647g;
            this.f6665h = bVar.f6648h;
            this.f6666i = bVar.f6649i;
            this.f6667j = bVar.f6654n;
            this.f6668k = bVar.f6655o;
            this.f6669l = bVar.f6650j;
            this.f6670m = bVar.f6651k;
            this.f6671n = bVar.f6652l;
            this.f6672o = bVar.f6653m;
            this.f6673p = bVar.f6656p;
            this.f6674q = bVar.f6657q;
        }

        /* renamed from: a */
        public C1818b mo6009a() {
            return new C1818b(this.f6658a, this.f6660c, this.f6661d, this.f6659b, this.f6662e, this.f6663f, this.f6664g, this.f6665h, this.f6666i, this.f6667j, this.f6668k, this.f6669l, this.f6670m, this.f6671n, this.f6672o, this.f6673p, this.f6674q);
        }

        /* renamed from: b */
        public int mo6010b() {
            return this.f6664g;
        }

        /* renamed from: c */
        public int mo6011c() {
            return this.f6666i;
        }

        /* renamed from: d */
        public CharSequence mo6012d() {
            return this.f6658a;
        }

        /* renamed from: e */
        public C1820b mo6013e(Bitmap bitmap) {
            this.f6659b = bitmap;
            return this;
        }

        /* renamed from: f */
        public C1820b mo6014f(float f) {
            this.f6670m = f;
            return this;
        }

        /* renamed from: g */
        public C1820b mo6015g(float f, int i) {
            this.f6662e = f;
            this.f6663f = i;
            return this;
        }

        /* renamed from: h */
        public C1820b mo6016h(int i) {
            this.f6664g = i;
            return this;
        }

        /* renamed from: i */
        public C1820b mo6017i(Layout.Alignment alignment) {
            this.f6661d = alignment;
            return this;
        }

        /* renamed from: j */
        public C1820b mo6018j(float f) {
            this.f6665h = f;
            return this;
        }

        /* renamed from: k */
        public C1820b mo6019k(int i) {
            this.f6666i = i;
            return this;
        }

        /* renamed from: l */
        public C1820b mo6020l(float f) {
            this.f6674q = f;
            return this;
        }

        /* renamed from: m */
        public C1820b mo6021m(float f) {
            this.f6669l = f;
            return this;
        }

        /* renamed from: n */
        public C1820b mo6022n(CharSequence charSequence) {
            this.f6658a = charSequence;
            return this;
        }

        /* renamed from: o */
        public C1820b mo6023o(Layout.Alignment alignment) {
            this.f6660c = alignment;
            return this;
        }

        /* renamed from: p */
        public C1820b mo6024p(float f, int i) {
            this.f6668k = f;
            this.f6667j = i;
            return this;
        }

        /* renamed from: q */
        public C1820b mo6025q(int i) {
            this.f6673p = i;
            return this;
        }

        /* renamed from: r */
        public C1820b mo6026r(int i) {
            this.f6672o = i;
            this.f6671n = true;
            return this;
        }
    }

    static {
        C1820b bVar = new C1820b();
        bVar.mo6022n("");
        f6640r = bVar.mo6009a();
    }

    private C1818b(CharSequence charSequence, Layout.Alignment alignment, Layout.Alignment alignment2, Bitmap bitmap, float f, int i, int i2, float f2, int i3, int i4, float f3, float f4, float f5, boolean z, int i5, int i6, float f6) {
        if (charSequence == null) {
            C2030g.m9540e(bitmap);
        } else {
            C2030g.m9536a(bitmap == null);
        }
        this.f6641a = charSequence instanceof Spanned ? SpannedString.valueOf(charSequence) : charSequence != null ? charSequence.toString() : null;
        this.f6642b = alignment;
        this.f6643c = alignment2;
        this.f6644d = bitmap;
        this.f6645e = f;
        this.f6646f = i;
        this.f6647g = i2;
        this.f6648h = f2;
        this.f6649i = i3;
        this.f6650j = f4;
        this.f6651k = f5;
        this.f6652l = z;
        this.f6653m = i5;
        this.f6654n = i4;
        this.f6655o = f3;
        this.f6656p = i6;
        this.f6657q = f6;
    }

    /* renamed from: a */
    public C1820b mo6008a() {
        return new C1820b();
    }
}
