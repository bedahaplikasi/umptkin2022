package p052c.p070d.p071a.p083b.p102s2;

import p052c.p070d.p071a.p083b.C1067e1;
import p052c.p070d.p071a.p083b.C1110k1;
import p052c.p070d.p071a.p083b.p102s2.C1612a;

/* renamed from: c.d.a.b.s2.b */
public final /* synthetic */ class C1615b {
    /* renamed from: a */
    public static byte[] m7745a(C1612a.C1614b bVar) {
        return null;
    }

    /* renamed from: b */
    public static C1067e1 m7746b(C1612a.C1614b bVar) {
        return null;
    }

    /* renamed from: c */
    public static void m7747c(C1612a.C1614b bVar, C1110k1.C1112b bVar2) {
    }
}
