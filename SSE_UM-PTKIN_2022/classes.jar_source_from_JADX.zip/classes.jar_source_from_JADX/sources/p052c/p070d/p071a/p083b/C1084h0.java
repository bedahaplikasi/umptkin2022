package p052c.p070d.p071a.p083b;

/* renamed from: c.d.a.b.h0 */
public final /* synthetic */ class C1084h0 implements C1567r0 {

    /* renamed from: a */
    public static final C1084h0 f3934a = new C1084h0();

    private /* synthetic */ C1084h0() {
    }
}
