package p052c.p070d.p071a.p083b;

/* renamed from: c.d.a.b.z */
public final /* synthetic */ class C2079z implements Runnable {

    /* renamed from: c */
    public final C1047b1 f7577c;

    /* renamed from: d */
    public final C1903w1 f7578d;

    public /* synthetic */ C2079z(C1047b1 b1Var, C1903w1 w1Var) {
        this.f7577c = b1Var;
        this.f7578d = w1Var;
    }

    public final void run() {
        this.f7577c.mo4306Q(this.f7578d);
    }
}
