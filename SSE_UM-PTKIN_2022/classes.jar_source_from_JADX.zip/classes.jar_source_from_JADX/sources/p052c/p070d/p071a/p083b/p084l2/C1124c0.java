package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.c0 */
public final /* synthetic */ class C1124c0 implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4124a;

    /* renamed from: b */
    public final int f4125b;

    /* renamed from: c */
    public final long f4126c;

    public /* synthetic */ C1124c0(C1138g1.C1139a aVar, int i, long j) {
        this.f4124a = aVar;
        this.f4125b = i;
        this.f4126c = j;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        ((C1138g1) obj).mo4678i(this.f4124a, this.f4125b, this.f4126c);
    }
}
