package p052c.p070d.p071a.p083b;

import p052c.p070d.p071a.p083b.C1696t1;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.i */
public final /* synthetic */ class C1090i implements C2065t.C2066a {

    /* renamed from: a */
    public final C1568r1 f3944a;

    public /* synthetic */ C1090i(C1568r1 r1Var) {
        this.f3944a = r1Var;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        ((C1696t1.C1700c) obj).mo4453n0(C1041a1.m4576U(this.f3944a));
    }
}
