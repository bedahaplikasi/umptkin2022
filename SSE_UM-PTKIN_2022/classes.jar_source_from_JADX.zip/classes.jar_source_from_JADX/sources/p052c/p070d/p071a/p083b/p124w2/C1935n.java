package p052c.p070d.p071a.p083b.p124w2;

import p052c.p070d.p071a.p083b.C1060c2;
import p052c.p070d.p071a.p083b.C1093i2;
import p052c.p070d.p071a.p083b.p111u2.C1725f0;
import p052c.p070d.p071a.p083b.p111u2.C1776t0;
import p052c.p070d.p071a.p083b.p125x2.C1968h;
import p052c.p070d.p071a.p083b.p126y2.C2030g;

/* renamed from: c.d.a.b.w2.n */
public abstract class C1935n {

    /* renamed from: a */
    private C1968h f7216a;

    /* renamed from: c.d.a.b.w2.n$a */
    public interface C1936a {
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public final C1968h mo6264a() {
        C1968h hVar = this.f7216a;
        C2030g.m9540e(hVar);
        return hVar;
    }

    /* renamed from: b */
    public final void mo6265b(C1936a aVar, C1968h hVar) {
        this.f7216a = hVar;
    }

    /* renamed from: c */
    public abstract void mo6253c(Object obj);

    /* renamed from: d */
    public abstract C1937o mo6254d(C1060c2[] c2VarArr, C1776t0 t0Var, C1725f0.C1726a aVar, C1093i2 i2Var);
}
