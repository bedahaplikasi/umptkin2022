package p052c.p070d.p071a.p083b;

import java.util.List;
import p052c.p070d.p071a.p083b.C1696t1;
import p052c.p070d.p071a.p083b.p111u2.C1776t0;
import p052c.p070d.p071a.p083b.p124w2.C1931l;

/* renamed from: c.d.a.b.u1 */
public final /* synthetic */ class C1710u1 {
    /* renamed from: a */
    public static void m7992a(C1696t1.C1700c cVar, C1696t1.C1698b bVar) {
    }

    /* renamed from: b */
    public static void m7993b(C1696t1.C1700c cVar, C1696t1 t1Var, C1696t1.C1701d dVar) {
    }

    /* renamed from: c */
    public static void m7994c(C1696t1.C1700c cVar, boolean z) {
    }

    /* renamed from: d */
    public static void m7995d(C1696t1.C1700c cVar, boolean z) {
    }

    @Deprecated
    /* renamed from: e */
    public static void m7996e(C1696t1.C1700c cVar, boolean z) {
    }

    /* renamed from: f */
    public static void m7997f(C1696t1.C1700c cVar, C1099j1 j1Var, int i) {
    }

    /* renamed from: g */
    public static void m7998g(C1696t1.C1700c cVar, C1110k1 k1Var) {
    }

    /* renamed from: h */
    public static void m7999h(C1696t1.C1700c cVar, boolean z, int i) {
    }

    /* renamed from: i */
    public static void m8000i(C1696t1.C1700c cVar, C1611s1 s1Var) {
    }

    /* renamed from: j */
    public static void m8001j(C1696t1.C1700c cVar, int i) {
    }

    /* renamed from: k */
    public static void m8002k(C1696t1.C1700c cVar, C1939x0 x0Var) {
    }

    @Deprecated
    /* renamed from: l */
    public static void m8003l(C1696t1.C1700c cVar, boolean z, int i) {
    }

    @Deprecated
    /* renamed from: m */
    public static void m8004m(C1696t1.C1700c cVar, int i) {
    }

    /* renamed from: n */
    public static void m8005n(C1696t1.C1700c cVar, C1696t1.C1703f fVar, C1696t1.C1703f fVar2, int i) {
    }

    /* renamed from: o */
    public static void m8006o(C1696t1.C1700c cVar, int i) {
    }

    @Deprecated
    /* renamed from: p */
    public static void m8007p(C1696t1.C1700c cVar) {
    }

    /* renamed from: q */
    public static void m8008q(C1696t1.C1700c cVar, List list) {
    }

    /* renamed from: r */
    public static void m8009r(C1696t1.C1700c cVar, C1093i2 i2Var, int i) {
    }

    @Deprecated
    /* renamed from: s */
    public static void m8010s(C1696t1.C1700c cVar, C1093i2 i2Var, Object obj, int i) {
    }

    /* renamed from: t */
    public static void m8011t(C1696t1.C1700c cVar, C1776t0 t0Var, C1931l lVar) {
    }
}
