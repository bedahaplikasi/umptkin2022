package p052c.p070d.p071a.p083b;

import android.net.Uri;
import android.os.Bundle;
import java.util.Arrays;
import java.util.List;
import p052c.p070d.p071a.p083b.p102s2.C1612a;
import p052c.p070d.p071a.p083b.p126y2.C2058o0;
import p052c.p070d.p139b.p140a.C2244h;

/* renamed from: c.d.a.b.k1 */
public final class C1110k1 {

    /* renamed from: s */
    public static final C1110k1 f4049s = new C1112b().mo4570s();

    /* renamed from: t */
    public static final C1567r0<C1110k1> f4050t = C1062d0.f3779a;

    /* renamed from: a */
    public final CharSequence f4051a;

    /* renamed from: b */
    public final CharSequence f4052b;

    /* renamed from: c */
    public final CharSequence f4053c;

    /* renamed from: d */
    public final CharSequence f4054d;

    /* renamed from: e */
    public final CharSequence f4055e;

    /* renamed from: f */
    public final CharSequence f4056f;

    /* renamed from: g */
    public final CharSequence f4057g;

    /* renamed from: h */
    public final Uri f4058h;

    /* renamed from: i */
    public final C2011y1 f4059i;

    /* renamed from: j */
    public final C2011y1 f4060j;

    /* renamed from: k */
    public final byte[] f4061k;

    /* renamed from: l */
    public final Uri f4062l;

    /* renamed from: m */
    public final Integer f4063m;

    /* renamed from: n */
    public final Integer f4064n;

    /* renamed from: o */
    public final Integer f4065o;

    /* renamed from: p */
    public final Boolean f4066p;

    /* renamed from: q */
    public final Integer f4067q;

    /* renamed from: r */
    public final Bundle f4068r;

    /* renamed from: c.d.a.b.k1$b */
    public static final class C1112b {
        /* access modifiers changed from: private */

        /* renamed from: a */
        public CharSequence f4069a;
        /* access modifiers changed from: private */

        /* renamed from: b */
        public CharSequence f4070b;
        /* access modifiers changed from: private */

        /* renamed from: c */
        public CharSequence f4071c;
        /* access modifiers changed from: private */

        /* renamed from: d */
        public CharSequence f4072d;
        /* access modifiers changed from: private */

        /* renamed from: e */
        public CharSequence f4073e;
        /* access modifiers changed from: private */

        /* renamed from: f */
        public CharSequence f4074f;
        /* access modifiers changed from: private */

        /* renamed from: g */
        public CharSequence f4075g;
        /* access modifiers changed from: private */

        /* renamed from: h */
        public Uri f4076h;
        /* access modifiers changed from: private */

        /* renamed from: i */
        public C2011y1 f4077i;
        /* access modifiers changed from: private */

        /* renamed from: j */
        public C2011y1 f4078j;
        /* access modifiers changed from: private */

        /* renamed from: k */
        public byte[] f4079k;
        /* access modifiers changed from: private */

        /* renamed from: l */
        public Uri f4080l;
        /* access modifiers changed from: private */

        /* renamed from: m */
        public Integer f4081m;
        /* access modifiers changed from: private */

        /* renamed from: n */
        public Integer f4082n;
        /* access modifiers changed from: private */

        /* renamed from: o */
        public Integer f4083o;
        /* access modifiers changed from: private */

        /* renamed from: p */
        public Boolean f4084p;
        /* access modifiers changed from: private */

        /* renamed from: q */
        public Integer f4085q;
        /* access modifiers changed from: private */

        /* renamed from: r */
        public Bundle f4086r;

        public C1112b() {
        }

        private C1112b(C1110k1 k1Var) {
            this.f4069a = k1Var.f4051a;
            this.f4070b = k1Var.f4052b;
            this.f4071c = k1Var.f4053c;
            this.f4072d = k1Var.f4054d;
            this.f4073e = k1Var.f4055e;
            this.f4074f = k1Var.f4056f;
            this.f4075g = k1Var.f4057g;
            this.f4076h = k1Var.f4058h;
            this.f4077i = k1Var.f4059i;
            this.f4078j = k1Var.f4060j;
            this.f4079k = k1Var.f4061k;
            this.f4080l = k1Var.f4062l;
            this.f4081m = k1Var.f4063m;
            this.f4082n = k1Var.f4064n;
            this.f4083o = k1Var.f4065o;
            this.f4084p = k1Var.f4066p;
            this.f4085q = k1Var.f4067q;
            this.f4086r = k1Var.f4068r;
        }

        /* renamed from: A */
        public C1112b mo4567A(Integer num) {
            this.f4082n = num;
            return this;
        }

        /* renamed from: B */
        public C1112b mo4568B(Integer num) {
            this.f4081m = num;
            return this;
        }

        /* renamed from: C */
        public C1112b mo4569C(Integer num) {
            this.f4085q = num;
            return this;
        }

        /* renamed from: s */
        public C1110k1 mo4570s() {
            return new C1110k1(this);
        }

        /* renamed from: t */
        public C1112b mo4571t(C1612a aVar) {
            for (int i = 0; i < aVar.mo5470g(); i++) {
                aVar.mo5469f(i).mo5478a(this);
            }
            return this;
        }

        /* renamed from: u */
        public C1112b mo4572u(List<C1612a> list) {
            for (int i = 0; i < list.size(); i++) {
                C1612a aVar = list.get(i);
                for (int i2 = 0; i2 < aVar.mo5470g(); i2++) {
                    aVar.mo5469f(i2).mo5478a(this);
                }
            }
            return this;
        }

        /* renamed from: v */
        public C1112b mo4573v(CharSequence charSequence) {
            this.f4072d = charSequence;
            return this;
        }

        /* renamed from: w */
        public C1112b mo4574w(CharSequence charSequence) {
            this.f4071c = charSequence;
            return this;
        }

        /* renamed from: x */
        public C1112b mo4575x(CharSequence charSequence) {
            this.f4070b = charSequence;
            return this;
        }

        /* renamed from: y */
        public C1112b mo4576y(byte[] bArr) {
            this.f4079k = bArr == null ? null : (byte[]) bArr.clone();
            return this;
        }

        /* renamed from: z */
        public C1112b mo4577z(CharSequence charSequence) {
            this.f4069a = charSequence;
            return this;
        }
    }

    private C1110k1(C1112b bVar) {
        this.f4051a = bVar.f4069a;
        this.f4052b = bVar.f4070b;
        this.f4053c = bVar.f4071c;
        this.f4054d = bVar.f4072d;
        this.f4055e = bVar.f4073e;
        this.f4056f = bVar.f4074f;
        this.f4057g = bVar.f4075g;
        this.f4058h = bVar.f4076h;
        this.f4059i = bVar.f4077i;
        this.f4060j = bVar.f4078j;
        this.f4061k = bVar.f4079k;
        this.f4062l = bVar.f4080l;
        this.f4063m = bVar.f4081m;
        this.f4064n = bVar.f4082n;
        this.f4065o = bVar.f4083o;
        this.f4066p = bVar.f4084p;
        this.f4067q = bVar.f4085q;
        this.f4068r = bVar.f4086r;
    }

    /* renamed from: a */
    public C1112b mo4564a() {
        return new C1112b();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || C1110k1.class != obj.getClass()) {
            return false;
        }
        C1110k1 k1Var = (C1110k1) obj;
        return C2058o0.m9709b(this.f4051a, k1Var.f4051a) && C2058o0.m9709b(this.f4052b, k1Var.f4052b) && C2058o0.m9709b(this.f4053c, k1Var.f4053c) && C2058o0.m9709b(this.f4054d, k1Var.f4054d) && C2058o0.m9709b(this.f4055e, k1Var.f4055e) && C2058o0.m9709b(this.f4056f, k1Var.f4056f) && C2058o0.m9709b(this.f4057g, k1Var.f4057g) && C2058o0.m9709b(this.f4058h, k1Var.f4058h) && C2058o0.m9709b(this.f4059i, k1Var.f4059i) && C2058o0.m9709b(this.f4060j, k1Var.f4060j) && Arrays.equals(this.f4061k, k1Var.f4061k) && C2058o0.m9709b(this.f4062l, k1Var.f4062l) && C2058o0.m9709b(this.f4063m, k1Var.f4063m) && C2058o0.m9709b(this.f4064n, k1Var.f4064n) && C2058o0.m9709b(this.f4065o, k1Var.f4065o) && C2058o0.m9709b(this.f4066p, k1Var.f4066p) && C2058o0.m9709b(this.f4067q, k1Var.f4067q);
    }

    public int hashCode() {
        return C2244h.m10281b(this.f4051a, this.f4052b, this.f4053c, this.f4054d, this.f4055e, this.f4056f, this.f4057g, this.f4058h, this.f4059i, this.f4060j, Integer.valueOf(Arrays.hashCode(this.f4061k)), this.f4062l, this.f4063m, this.f4064n, this.f4065o, this.f4066p, this.f4067q);
    }
}
