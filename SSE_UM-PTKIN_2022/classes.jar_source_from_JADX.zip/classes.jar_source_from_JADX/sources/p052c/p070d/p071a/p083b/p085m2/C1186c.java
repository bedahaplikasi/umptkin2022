package p052c.p070d.p071a.p083b.p085m2;

import p052c.p070d.p071a.p083b.p085m2.C1240v;
import p052c.p070d.p071a.p083b.p086n2.C1263d;

/* renamed from: c.d.a.b.m2.c */
public final /* synthetic */ class C1186c implements Runnable {

    /* renamed from: c */
    public final C1240v.C1241a f4288c;

    /* renamed from: d */
    public final C1263d f4289d;

    public /* synthetic */ C1186c(C1240v.C1241a aVar, C1263d dVar) {
        this.f4288c = aVar;
        this.f4289d = dVar;
    }

    public final void run() {
        this.f4288c.mo4866q(this.f4289d);
    }
}
