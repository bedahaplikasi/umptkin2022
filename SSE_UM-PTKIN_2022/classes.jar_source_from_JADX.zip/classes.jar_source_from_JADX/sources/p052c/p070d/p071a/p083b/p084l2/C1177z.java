package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.z */
public final /* synthetic */ class C1177z implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4258a;

    /* renamed from: b */
    public final int f4259b;

    public /* synthetic */ C1177z(C1138g1.C1139a aVar, int i) {
        this.f4258a = aVar;
        this.f4259b = i;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        ((C1138g1) obj).mo4673f0(this.f4258a, this.f4259b);
    }
}
