package p052c.p070d.p071a.p083b.p114v2;

import java.util.List;

/* renamed from: c.d.a.b.v2.k */
public interface C1830k {
    /* renamed from: F */
    void mo4418F(List<C1818b> list);
}
