package p052c.p070d.p071a.p083b.p089q2;

import android.net.Uri;
import java.util.Map;

/* renamed from: c.d.a.b.q2.n */
public final /* synthetic */ class C1485n {
    /* renamed from: a */
    public static C1419j[] m7023a(C1540o oVar, Uri uri, Map map) {
        return oVar.mo5109a();
    }

    /* renamed from: b */
    public static /* synthetic */ C1419j[] m7024b() {
        return new C1419j[0];
    }
}
