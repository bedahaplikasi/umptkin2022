package p052c.p070d.p071a.p083b.p085m2;

import p052c.p070d.p071a.p083b.p085m2.C1240v;

/* renamed from: c.d.a.b.m2.b */
public final /* synthetic */ class C1184b implements Runnable {

    /* renamed from: c */
    public final C1240v.C1241a f4284c;

    /* renamed from: d */
    public final boolean f4285d;

    public /* synthetic */ C1184b(C1240v.C1241a aVar, boolean z) {
        this.f4284c = aVar;
        this.f4285d = z;
    }

    public final void run() {
        this.f4284c.mo4870y(this.f4285d);
    }
}
