package p052c.p070d.p071a.p083b.p089q2.p092g0;

import android.net.Uri;
import java.util.Map;
import p052c.p070d.p071a.p083b.p089q2.C1419j;
import p052c.p070d.p071a.p083b.p089q2.C1485n;
import p052c.p070d.p071a.p083b.p089q2.C1540o;

/* renamed from: c.d.a.b.q2.g0.a */
public final /* synthetic */ class C1390a implements C1540o {

    /* renamed from: a */
    public static final C1390a f4938a = new C1390a();

    private /* synthetic */ C1390a() {
    }

    /* renamed from: a */
    public final C1419j[] mo5109a() {
        return C1392c.m6508g();
    }

    /* renamed from: b */
    public /* synthetic */ C1419j[] mo5110b(Uri uri, Map map) {
        return C1485n.m7023a(this, uri, map);
    }
}
