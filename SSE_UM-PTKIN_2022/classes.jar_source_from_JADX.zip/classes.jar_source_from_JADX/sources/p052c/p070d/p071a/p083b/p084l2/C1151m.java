package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p086n2.C1263d;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.m */
public final /* synthetic */ class C1151m implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4202a;

    /* renamed from: b */
    public final C1263d f4203b;

    public /* synthetic */ C1151m(C1138g1.C1139a aVar, C1263d dVar) {
        this.f4202a = aVar;
        this.f4203b = dVar;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        C1134f1.m5256t1(this.f4202a, this.f4203b, (C1138g1) obj);
    }
}
