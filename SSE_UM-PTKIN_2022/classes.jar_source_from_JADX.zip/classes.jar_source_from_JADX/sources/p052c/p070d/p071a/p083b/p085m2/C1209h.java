package p052c.p070d.p071a.p083b.p085m2;

import p052c.p070d.p071a.p083b.p085m2.C1240v;

/* renamed from: c.d.a.b.m2.h */
public final /* synthetic */ class C1209h implements Runnable {

    /* renamed from: c */
    public final C1240v.C1241a f4411c;

    /* renamed from: d */
    public final String f4412d;

    public /* synthetic */ C1209h(C1240v.C1241a aVar, String str) {
        this.f4411c = aVar;
        this.f4412d = str;
    }

    public final void run() {
        this.f4411c.mo4865o(this.f4412d);
    }
}
