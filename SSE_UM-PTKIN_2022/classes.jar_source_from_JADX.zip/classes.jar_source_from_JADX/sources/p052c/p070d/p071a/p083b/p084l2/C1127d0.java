package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.d0 */
public final /* synthetic */ class C1127d0 implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4131a;

    /* renamed from: b */
    public final int f4132b;

    /* renamed from: c */
    public final long f4133c;

    /* renamed from: d */
    public final long f4134d;

    public /* synthetic */ C1127d0(C1138g1.C1139a aVar, int i, long j, long j2) {
        this.f4131a = aVar;
        this.f4132b = i;
        this.f4133c = j;
        this.f4134d = j2;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        ((C1138g1) obj).mo4662a(this.f4131a, this.f4132b, this.f4133c, this.f4134d);
    }
}
