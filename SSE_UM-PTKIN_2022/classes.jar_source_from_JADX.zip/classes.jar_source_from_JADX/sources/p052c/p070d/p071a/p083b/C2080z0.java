package p052c.p070d.p071a.p083b;

/* renamed from: c.d.a.b.z0 */
public interface C2080z0 {
    /* renamed from: A */
    void mo4413A(boolean z);

    /* renamed from: x */
    void mo4470x(boolean z);
}
