package p052c.p070d.p071a.p083b.p089q2.p094i0;

import p052c.p070d.p071a.p083b.p089q2.C1430k;

/* renamed from: c.d.a.b.q2.i0.d */
interface C1411d {
    /* renamed from: b */
    boolean mo5172b(C1430k kVar);

    /* renamed from: c */
    void mo5173c();

    /* renamed from: d */
    void mo5174d(C1410c cVar);
}
