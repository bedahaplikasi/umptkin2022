package p052c.p070d.p071a.p083b.p124w2;

import java.util.List;
import p052c.p070d.p071a.p083b.C1067e1;
import p052c.p070d.p071a.p083b.C1093i2;
import p052c.p070d.p071a.p083b.p111u2.C1725f0;
import p052c.p070d.p071a.p083b.p111u2.C1773s0;
import p052c.p070d.p071a.p083b.p111u2.p113w0.C1792f;
import p052c.p070d.p071a.p083b.p111u2.p113w0.C1804n;
import p052c.p070d.p071a.p083b.p111u2.p113w0.C1805o;
import p052c.p070d.p071a.p083b.p125x2.C1968h;

/* renamed from: c.d.a.b.w2.h */
public interface C1924h extends C1930k {

    /* renamed from: c.d.a.b.w2.h$a */
    public static final class C1925a {

        /* renamed from: a */
        public final C1773s0 f7193a;

        /* renamed from: b */
        public final int[] f7194b;

        /* renamed from: c */
        public final int f7195c;

        public C1925a(C1773s0 s0Var, int... iArr) {
            this(s0Var, iArr, 0);
        }

        public C1925a(C1773s0 s0Var, int[] iArr, int i) {
            this.f7193a = s0Var;
            this.f7194b = iArr;
            this.f7195c = i;
        }
    }

    /* renamed from: c.d.a.b.w2.h$b */
    public interface C1926b {
        /* renamed from: a */
        C1924h[] mo6196a(C1925a[] aVarArr, C1968h hVar, C1725f0.C1726a aVar, C1093i2 i2Var);
    }

    /* renamed from: a */
    boolean mo6198a(int i, long j);

    /* renamed from: b */
    boolean mo6199b(long j, C1792f fVar, List<? extends C1804n> list);

    /* renamed from: c */
    void mo6200c(boolean z);

    /* renamed from: e */
    void mo6185e();

    /* renamed from: f */
    void mo6186f();

    /* renamed from: h */
    int mo6187h(long j, List<? extends C1804n> list);

    /* renamed from: j */
    void mo6188j(long j, long j2, long j3, List<? extends C1804n> list, C1805o[] oVarArr);

    /* renamed from: k */
    int mo6206k();

    /* renamed from: m */
    C1067e1 mo6209m();

    /* renamed from: n */
    int mo6189n();

    /* renamed from: o */
    int mo6190o();

    /* renamed from: p */
    void mo6191p(float f);

    /* renamed from: q */
    Object mo6192q();

    /* renamed from: r */
    void mo6210r();

    /* renamed from: s */
    void mo6211s();
}
