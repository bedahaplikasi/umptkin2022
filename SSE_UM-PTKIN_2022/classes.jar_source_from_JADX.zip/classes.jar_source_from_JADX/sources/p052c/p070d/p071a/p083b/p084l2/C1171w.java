package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p111u2.C1716b0;
import p052c.p070d.p071a.p083b.p111u2.C1810y;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.w */
public final /* synthetic */ class C1171w implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4245a;

    /* renamed from: b */
    public final C1810y f4246b;

    /* renamed from: c */
    public final C1716b0 f4247c;

    public /* synthetic */ C1171w(C1138g1.C1139a aVar, C1810y yVar, C1716b0 b0Var) {
        this.f4245a = aVar;
        this.f4246b = yVar;
        this.f4247c = b0Var;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        ((C1138g1) obj).mo4696s(this.f4245a, this.f4246b, this.f4247c);
    }
}
