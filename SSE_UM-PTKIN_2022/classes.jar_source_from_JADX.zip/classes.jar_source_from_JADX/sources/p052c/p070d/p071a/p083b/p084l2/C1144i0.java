package p052c.p070d.p071a.p083b.p084l2;

import p052c.p070d.p071a.p083b.C1067e1;
import p052c.p070d.p071a.p083b.p084l2.C1138g1;
import p052c.p070d.p071a.p083b.p086n2.C1267g;
import p052c.p070d.p071a.p083b.p126y2.C2065t;

/* renamed from: c.d.a.b.l2.i0 */
public final /* synthetic */ class C1144i0 implements C2065t.C2066a {

    /* renamed from: a */
    public final C1138g1.C1139a f4182a;

    /* renamed from: b */
    public final C1067e1 f4183b;

    /* renamed from: c */
    public final C1267g f4184c;

    public /* synthetic */ C1144i0(C1138g1.C1139a aVar, C1067e1 e1Var, C1267g gVar) {
        this.f4182a = aVar;
        this.f4183b = e1Var;
        this.f4184c = gVar;
    }

    /* renamed from: a */
    public final void mo4234a(Object obj) {
        C1134f1.m5210D0(this.f4182a, this.f4183b, this.f4184c, (C1138g1) obj);
    }
}
